# Phase-by-phase implementation log

This document maps each phase from the system spec to the actual files
that implement it, so a future maintainer can find the seams quickly.

## v2.2 — spawn-oracle architecture (current release)

v2.1 shipped with NPC and traffic spawning DISABLED by default because
the server had no road/path data and was dropping cars into buildings.
v2.2 fixes that without embedding nav data on the server: instead, the
**client** is the oracle for any path-network query.

**New wire messages** (Protocol.h, kProtocolVersion=3):

- `MSG_SPAWN_QUERY = 16`  S→C  `{ qid, type, hintX,hintY,hintZ, minD, maxD }`
- `MSG_SPAWN_REPLY = 17`  C→S  `{ qid, ok, x,y,z, heading }`
- `MSG_NODE_QUERY  = 18`  S→C  `{ qid, type, curX,curY,curZ }`
- `MSG_NODE_REPLY  = 19`  C→S  `{ qid, ok, x,y,z, heading }`

`type`: `0 = PATH_CAR`, `1 = PATH_PED`.

**Client** (`MultiplayerClient::HandleSpawnQuery` /
`HandleNodeQuery`):

- For SPAWN_QUERY+PATH_PED: calls `ThePaths.GeneratePedCreationCoors`
  with the hint coord and the server's distance band, returns a real
  sidewalk coord.
- For SPAWN_QUERY+PATH_CAR: picks a random direction, calls
  `ThePaths.GenerateCarCreationCoors`, returns a real road coord.
- For NODE_QUERY: calls `ThePaths.FindNodeClosestToCoors` then
  `FindNextNodeWandering` to pick a real adjacent path node.
- Replies are sent on the same TCP connection.

**Server** (`server.py`):

- `pending_queries{qid -> {callback, expire}}` + `queries_lock`. Each
  query times out after `QUERY_TIMEOUT_SEC` so the in-flight counters
  can't leak.
- `step_npcs` / `step_traffic`:
  - Move every entity linearly toward its current waypoint
    `(tx, ty, tz)` at `NPC_SPEED_WALK` / `TRAFFIC_SPEED`.
  - When arrived (within `NPC_ARRIVE_DIST` / `TRAFFIC_ARRIVE_DIST`),
    fire `NODE_QUERY` to the nearest player. Reply callback fills
    the next waypoint.
  - When below `*_TARGET_PER_PLAYER`, fire `SPAWN_QUERY` (max 2 per
    tick per kind). Reply callback creates the entity at the
    engine-validated coord, allocs `nid`/`vid`, broadcast picks it
    up next tick.
- `MSG_SPAWN_REPLY` / `MSG_NODE_REPLY` handled in `client_thread`.
- `expire_old_queries` runs each tick to clean up stalled queries.
- `ShouldDisableLocalPopulation()` (client side) flipped back to
  `IsConnected() && WorldSync::HasReceivedTick()` so the engine's
  own population/traffic generators stop fighting the server.

**Verified MI_* values** (`ModelIndices.h`):

- Pedestrian models 7..28 are hardcoded enum values
  (`MI_MALE01 = 7`, `MI_HFYST = 9`, ..., `MI_HMOCA = 28`) - safe to
  use as runtime indices directly.
- Vehicle models start at `MI_FIRST_VEHICLE = 130` (sequential enum):
  `MI_LANDSTAL = 130`, `MI_IDAHO = 131`, ..., `MI_TAXI = 150`,
  `MI_BOBCAT = 152`. Curated set used in `TRAFFIC_MODELS`.
- Pickup `MI_*` are *runtime* `extern int16` globals set from IDE name
  lookup; they CAN'T be hardcoded on the server. Pickup spawning is
  therefore still empty by default in v2.2 and will need a
  `MSG_MODEL_TABLE` round-trip from the client (deferred).

**Files changed in v2.2:**
- `reVC/src/multiplayer/Protocol.h`         (+4 msg types, +4 structs, version 3)
- `reVC/src/multiplayer/MultiplayerClient.h`(+ HandleSpawnQuery / HandleNodeQuery)
- `reVC/src/multiplayer/MultiplayerClient.cpp`(+ oracle handlers, ShouldDisableLocalPopulation re-enabled)
- `server/server.py`                        (spawn-oracle protocol, rewritten step_npcs / step_traffic)
- `README.md`, `PHASES.md`                  (v2.2 architecture)

---

## v2.1 hotfix summary

After v2 shipped, real-world testing showed three problems:

1. **Weather thrashed.** The first `WorldSync::Apply` was overwriting
   `CWeather::OldWeatherType` / `NewWeatherType` /
   `InterpolationValue` every server tick (1 Hz), fighting the engine's
   own `CWeather::Update` and causing the sky to flicker between
   weather states many times per second.
2. **Cars spawned through walls.** The server was spawning traffic at
   random positions in a circle around each player. Without the
   engine's road data, these positions land inside buildings or in the
   ocean, producing physics chaos. Worse, the spawn loop was
   `target = total + X*players; while len < target`, which re-evaluated
   `total` after each spawn and effectively burst-filled the pool.
3. **Engine crashed.** Server NPC and pickup model indices were
   guessed (e.g. `MI_HFYBE = 9`, `MI_MONEY = 1274`) and were not
   verified against the actual engine `ModelIndices.h`. Constructing
   `CCivilianPed(PEDTYPE_CIVMALE, modelIdx)` or calling
   `CPickups::GenerateNewOne(...)` with an invalid model crashes the
   streaming subsystem.

Fixes shipped in v2.1:
- `WorldSync::Apply` now only re-applies time when (hour, minute)
  actually change, and only forces a weather change when the index
  actually changes (via `CWeather::ForceWeatherNow`). It no longer
  touches `InterpolationValue`.
- `step_traffic` rewritten with a fixed target count and a per-tick
  `spawn_budget` of 2.
- `NPC_TARGET_PER_PLAYER`, `TRAFFIC_TARGET_PER_PLAYER`, and
  `PICKUP_SPAWN_POINTS` are all set to disabled / empty by default.
- `MultiplayerClient::ShouldDisableLocalPopulation()` returns `false`,
  so engine-side population/traffic generators keep running. The
  Game.cpp.patch becomes a no-op until Phase 6.

Net effect: the game boots cleanly, weather changes smoothly every
~10 minutes, and player + vehicle + time + weather sync still work.
Phases 4 + 5 ship as infrastructure ready for Phase 6 nav data.

## Phase 1 — Time + Weather sync

**Goal:** every connected client shows the same hour/minute and the
same weather (with smooth blend), driven by the server.

**Wire:**  `MSG_WORLD_TICK = 10` (`<BBBBBf>` = h, m, dow, oldW, newW, interp).

**Server (`server/server.py`):**
- `class World` advances `time_h/time_m` at `TIME_MIN_PER_SEC`
  in-game minutes per real second.
- Cycles through `WEATHER_CYCLE` every `WEATHER_PHASE_SEC`.
- `world_tick_thread` broadcasts `MSG_WORLD_TICK` at `WORLD_TICK_HZ`.

**Client (`reVC/src/multiplayer/`):**
- `WorldSync.cpp::Apply()` writes `CClock::SetGameClock(h,m)` and
  `CWeather::OldWeatherType` / `NewWeatherType` / `InterpolationValue`,
  and clears `CWeather::ForcedWeatherType` so the engine no longer
  overrides.
- `MultiplayerClient::HandleMessage` dispatches `MSG_WORLD_TICK`.

---

## Phase 2 — Pickup sync

**Goal:** pickups (money, health, armour) are server-managed; once one
player takes a pickup all clients lose it; the server respawns it
after `PICKUP_RESPAWN_SEC`.

**Wire:**
- `MSG_PICKUP_SPAWN  = 13`  S→C: count + per-entry { id, model, type, x,y,z }
- `MSG_PICKUP_REMOVE = 14`  S→C: count + [id]
- `MSG_PICKUP_TAKE   = 15`  C→S: id

**Server:**
- `init_pickups()` populates `pickups{}` from `PICKUP_SPAWN_POINTS`.
- AOI broadcast loop sends only NEW alive pickups in each player's
  AOI (delta against `Player.known_pickups`) and removes pickups that
  left AOI or were taken.
- `MSG_PICKUP_TAKE` handler marks the pickup `alive=False` and sets
  `respawn_at = now + PICKUP_RESPAWN_SEC`.
- `step_pickups()` flips them back alive when the timer expires.

**Client:**
- `RemotePickup` wraps a slot in the engine's `CPickups::aPickUps[]`
  pool. Spawn calls `CPickups::GenerateNewOne(...)`.
- `RemotePickup::DetectLocalTake()` watches the slot's `m_eType`; the
  only thing that flips it to `PICKUP_NONE` locally is the local
  player walking through the pickup, which is exactly the event we
  want to forward as `MSG_PICKUP_TAKE`.
- `MultiplayerClient::DetectLocalPickupTakes()` calls that detector
  every frame.

---

## Phase 3 — Vehicle sync fix

**Goal:** the existing player-driven vehicle ownership (jacking) keeps
working, but the same `MSG_VEH_SNAPSHOT` channel also delivers
server-spawned traffic vehicles, so all clients see one consistent
set of cars.

**Wire:** `MSG_VEH_SNAPSHOT` entry now uses `ownerPid==0xFFFF` to mean
"server-owned traffic" (sentinel `kServerOwnedPid`). All other ownerPid
values mean "this player owns this car right now" (or 0 = abandoned).

**Server:**
- `assign_vehicle()` and `release_vehicle()` are unchanged from v1.
- AOI snapshot includes both player-owned AND server-owned vehicles
  inside the player's AOI in one snapshot.

**Client:**
- `MultiplayerClient::HandleVehSnapshot` skips local-jack detection
  when `ownerPid == kServerOwnedPid`. Server traffic just becomes a
  RemoteVehicle ghost that can be jacked normally — at jack time the
  client sends `MSG_VEH_ENTER` and the server reassigns ownership
  from the sentinel to the jacking player.

---

## Phase 4 — NPC sync

**Goal:** pedestrian NPCs are server-spawned and server-driven; same
NPC visible to every client inside its AOI.

**Wire:**
- `MSG_NPC_SNAPSHOT = 11`  S→C: count + per-entry { id, model, x,y,z, h, anim, health }
- `MSG_NPC_REMOVE   = 12`  S→C: count + [id]

**Server:**
- `step_npcs()` advances every NPC by simple wander AI (random
  heading change every 3-8 s, drifts at `NPC_SPEED_WALK`).
- Spawns near each player to maintain `NPC_TARGET_PER_PLAYER`,
  capped at `NPC_POOL_LIMIT`.
- AOI broadcaster sends full NPC state for in-AOI npcs each tick,
  and a `MSG_NPC_REMOVE` for any npc the client previously knew but
  no longer in AOI / despawned (delta against
  `Player.known_npcs`).

**Client:**
- `RemoteNPC` mirrors `RemotePlayer`'s structure: it owns a
  `CCivilianPed` in the world, parks AI, and drives pose by network
  interpolation. Anim swap goes through `CAnimManager::BlendAnimation`.
- `MultiplayerClient::HandleNpcSnapshot` creates/updates;
  `HandleNpcRemove` despawns.

---

## Phase 5 — Traffic sync

**Goal:** ambient traffic visible to every client.

This is layered on top of Phase 3's wire format. Server-owned
vehicles use `ownerPid == 0xFFFF`. The client treats them as ordinary
ghosts (RemoteVehicle), so animation, collision and visual state are
identical to player-driven cars — they just happen to be moved by
`step_traffic()` on the server.

`step_traffic()`:
- Spawns near each player up to `TRAFFIC_TARGET_PER_PLAYER`,
  respecting `TRAFFIC_POOL_LIMIT`.
- Drifts each car along a random heading at `TRAFFIC_SPEED` (this is
  intentionally simple; a future revision can add lane-following).
- Despawns when no player is within `TRAFFIC_DESPAWN_DIST`.

**Crucial engine-side gate:** `patches/Game.cpp.patch` disables
`CPopulation::Update`, `CTheCarGenerators::Process` and
`CCarCtrl::GenerateRandomCars` whenever the multiplayer client is
connected (`MultiplayerClient::ShouldDisableLocalPopulation()`).
Without this gate, each client would also spawn its own local
peds/cars on top of the server's, and you'd see double populations
that don't sync.

---

## Phase 6 — Optimization (future)

Not yet implemented. Suggested next steps in priority order:

1. **Move from TCP to UDP/ENet** for entity snapshots. Keep TCP for
   HELLO / WELCOME / VEH_ENTER / VEH_LEAVE / PICKUP_TAKE; use UDP
   for SNAPSHOT / VEH_SNAPSHOT / NPC_SNAPSHOT / WORLD_TICK. Replace
   `mp::TcpClient` with an ENet wrapper while keeping the framing
   constants in `Protocol.h`.
2. **Delta compression** of NPC/vehicle snapshots — send only entities
   whose pose changed since the last tick, plus a heartbeat list.
3. **Quantise pose to int16** (1 cm precision over a 32 km map fits
   in int16) for ~50% bandwidth reduction.
4. **Client-side prediction** for the local player: keep applying input
   locally, reconcile against server STATE acknowledgements.
5. **NPC pathfinding** — replace random wander with the server reading
   the engine's nav data (extract once and embed) so NPCs stay on
   sidewalks and don't walk into the ocean.

---

## Files added in v2

- `reVC/src/multiplayer/WorldSync.h`
- `reVC/src/multiplayer/WorldSync.cpp`
- `reVC/src/multiplayer/RemoteNPC.h`
- `reVC/src/multiplayer/RemoteNPC.cpp`
- `reVC/src/multiplayer/RemotePickup.h`
- `reVC/src/multiplayer/RemotePickup.cpp`
- `patches/Game.cpp.patch`
- `PHASES.md` (this file)

## Files updated in v2

- `reVC/src/multiplayer/Protocol.h`         (+6 message types, +6 structs)
- `reVC/src/multiplayer/MultiplayerClient.h`(+npcs/pickups maps, +world sync hook)
- `reVC/src/multiplayer/MultiplayerClient.cpp`(+5 message handlers, +pickup detector,
                                               +ShouldDisableLocalPopulation())
- `server/server.py`                        (full rewrite as world simulator)
- `README.md`                               (v2 architecture)
