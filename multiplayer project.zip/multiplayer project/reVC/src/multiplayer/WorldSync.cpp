// WorldSync.cpp - Push server time/weather into the engine globals.
//
// IMPORTANT v2.1 fix:
//   The engine's CWeather::Update() runs every frame and computes
//   InterpolationValue itself from CClock::GetMinutes()/60. Earlier
//   versions of this file overwrote OldWeatherType/NewWeatherType/
//   InterpolationValue every server tick (1 Hz), which fought
//   CWeather::Update and caused the sky to flicker between weather
//   states many times per second.
//
//   The fixed approach: only react when the SERVER's current weather
//   index actually changes - then call CWeather::ForceWeatherNow once,
//   which sets a smooth engine-managed transition. Between changes we
//   leave CWeather alone so the engine's natural interpolation runs.
//
//   For time, we only call CClock::SetGameClock when the (hour,minute)
//   pair we receive differs from the last one we applied - so the
//   engine's CClock::Update keeps rolling normally between server
//   ticks instead of being snapped backwards every second.
//
#include "common.h"

#include "WorldSync.h"

#include "Clock.h"
#include "Weather.h"

namespace mp {

static bool    s_received      = false;
static uint8_t s_lastHour      = 0xFF;
static uint8_t s_lastMinute    = 0xFF;
static uint8_t s_lastWeather   = 0xFF;

void WorldSync::Reset()
{
    s_received    = false;
    s_lastHour    = 0xFF;
    s_lastMinute  = 0xFF;
    s_lastWeather = 0xFF;
}

bool WorldSync::HasReceivedTick()
{
    return s_received;
}

void WorldSync::Apply(const WorldTickPayload& t)
{
    s_received = true;

    // Time: only re-stamp when the server's clock has actually advanced
    // beyond the last value we applied. CClock::Update keeps rolling in
    // between, so we don't snap the second hand backwards every tick.
    if (t.hour != s_lastHour || t.minute != s_lastMinute) {
        CClock::SetGameClock(t.hour, t.minute);
        s_lastHour   = t.hour;
        s_lastMinute = t.minute;
    }

    // Weather: only react on a real change. ForceWeatherNow sets up an
    // engine-managed transition with proper interpolation; calling it
    // every tick causes visible flicker.
    if (t.newWeather != s_lastWeather) {
        CWeather::ForceWeatherNow((int16)t.newWeather);
        // Clear any forced override so the engine's natural cycle can
        // continue between server ticks.
        CWeather::ForcedWeatherType = -1;
        s_lastWeather = t.newWeather;
    }

    // Note: t.oldWeather and t.interp are intentionally unused on the
    // client. The engine handles old/new blending itself once
    // ForceWeatherNow is called.
}

} // namespace mp
