// MultiplayerClient.cpp - networking + remote player/vehicle/NPC/pickup
// orchestration + server-authoritative world sync.
#include "common.h"

#include "MultiplayerClient.h"

#include "World.h"
#include "Ped.h"
#include "PlayerPed.h"
#include "PlayerInfo.h"
#include "Pad.h"
#include "Timer.h"
#include "Vector.h"
#include "Vehicle.h"
#include "Automobile.h"
#include "Bike.h"
#include "WeaponType.h"
#include "ModelInfo.h"
#include "Font.h"
#include "Text.h"
#include "PathFind.h"
#include "General.h"

#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <algorithm>

#ifdef __ANDROID__
#include <android/log.h>
#define MP_LOG(...) __android_log_print(ANDROID_LOG_INFO, "reVC_MP", __VA_ARGS__)
#else
#define MP_LOG(...) do { printf("[reVC_MP] " __VA_ARGS__); printf("\n"); } while(0)
#endif

namespace mp {

// --------------------------------------------------------------------------
// Config: /sdcard/Android/data/com.revc.game/files/multiplayer.cfg
// --------------------------------------------------------------------------
static const char* kConfigPath =
    "/sdcard/Android/data/com.revc.game/files/multiplayer.cfg";

static MultiplayerClient::CfgRef LoadConfig()
{
    MultiplayerClient::CfgRef c;
    FILE* f = std::fopen(kConfigPath, "r");
    if (!f) {
        MP_LOG("config file not found: %s -- multiplayer disabled", kConfigPath);
        FILE* w = std::fopen(kConfigPath, "w");
        if (w) {
            std::fprintf(w,
                "# reVC multiplayer config -- edit and restart the game\n"
                "server_ip=127.0.0.1\n"
                "server_port=7777\n"
                "player_name=Player\n");
            std::fclose(w);
            MP_LOG("wrote default config template -- edit and restart");
        }
        return c;
    }
    char line[256];
    while (std::fgets(line, sizeof(line), f)) {
        if (line[0] == '#' || line[0] == '\n') continue;
        char* eq = std::strchr(line, '=');
        if (!eq) continue;
        *eq = 0;
        std::string key = line;
        std::string val = eq + 1;
        while (!val.empty() &&
               (val.back() == '\n' || val.back() == '\r' || val.back() == ' '))
            val.pop_back();
        if (key == "server_ip")        c.host = val;
        else if (key == "server_port") c.port = (uint16_t)std::atoi(val.c_str());
        else if (key == "player_name") c.name = val;
    }
    std::fclose(f);
    c.enabled = true;
    MP_LOG("config loaded: host=%s port=%u name=%s",
           c.host.c_str(), (unsigned)c.port, c.name.c_str());
    return c;
}

// --------------------------------------------------------------------------

MultiplayerClient& MultiplayerClient::Get()
{
    static MultiplayerClient s_instance;
    return s_instance;
}

bool MultiplayerClient::ShouldDisableLocalPopulation()
{
    // v2.2: re-enabled. The server now spawns NPCs and traffic at engine-
    // validated positions via the SPAWN_QUERY/NODE_QUERY oracle protocol
    // (server asks our client to use ThePaths to find real road/sidewalk
    // coords). Once we receive at least one world tick we know the server
    // is alive and authoritative, so we turn the engine's local population
    // and traffic generators OFF to avoid duplicates with what the server
    // sends us via MSG_NPC_SNAPSHOT / MSG_VEH_SNAPSHOT.
    return MultiplayerClient::Get().IsConnected() &&
           WorldSync::HasReceivedTick();
}

MultiplayerClient::MultiplayerClient()
    : m_localId(kInvalidPlayerId),
      m_localVehPtr(nullptr),
      m_localVehNetId(0),
      m_localVehPendingModel(0),
      m_localVehEnterSentMs(0),
      m_lastSendMs(0),
      m_autoTried(false),
      m_lastReconnectMs(0)
{
    m_recvBuf.reserve(8192);
}

bool MultiplayerClient::Connect(const std::string& host, uint16_t port,
                                const std::string& name)
{
    Disconnect();
    MP_LOG("connecting to %s:%u as '%s' ...", host.c_str(), (unsigned)port, name.c_str());
    if (!m_net.Connect(host, port)) {
        MP_LOG("connect FAILED");
        return false;
    }
    MP_LOG("TCP connected, sending HELLO");

    m_name = name;
    m_localId = kInvalidPlayerId;
    WorldSync::Reset();

    uint8_t  nameLen = (uint8_t)std::min<size_t>(name.size(), (size_t)31);
    uint16_t payloadLen = (uint16_t)(1 + 1 + nameLen);
    uint8_t  buf[64];
    std::memcpy(buf, &payloadLen, 2);
    buf[2] = MSG_HELLO;
    buf[3] = nameLen;
    std::memcpy(&buf[4], name.data(), nameLen);
    m_net.Send(buf, 4 + nameLen);
    return true;
}

void MultiplayerClient::Disconnect()
{
    for (auto& kv : m_remotes)  { kv.second->Despawn();  delete kv.second; }
    for (auto& kv : m_vehicles) { kv.second->Despawn();  delete kv.second; }
    for (auto& kv : m_npcs)     { kv.second->Despawn();  delete kv.second; }
    for (auto& kv : m_pickups)  { kv.second->Despawn();  delete kv.second; }
    m_remotes.clear();
    m_vehicles.clear();
    m_npcs.clear();
    m_pickups.clear();
    m_recvBuf.clear();
    m_localId = kInvalidPlayerId;
    m_localVehPtr = nullptr;
    m_localVehNetId = 0;
    m_localVehPendingModel = 0;
    WorldSync::Reset();
    m_net.Disconnect();
}

void MultiplayerClient::Update()
{
    if (!m_autoTried) {
        m_autoTried = true;
        m_cfg = LoadConfig();
        if (m_cfg.enabled) {
            Connect(m_cfg.host, m_cfg.port, m_cfg.name);
            m_lastReconnectMs = CTimer::GetTimeInMilliseconds();
        }
    }

    uint32_t now = CTimer::GetTimeInMilliseconds();
    if (m_cfg.enabled && !m_net.IsConnected() &&
        (now - m_lastReconnectMs) > 5000) {
        m_lastReconnectMs = now;
        MP_LOG("auto-reconnect attempt");
        Connect(m_cfg.host, m_cfg.port, m_cfg.name);
    }

    DrawHud();

    if (!m_net.IsConnected()) return;

    ProcessIncoming();

    DetectLocalVehicleChange();
    DetectLocalPickupTakes();

    if (now - m_lastSendMs >= kSendIntervalMs) {
        SendLocalState();
        m_lastSendMs = now;
    }

    for (auto& kv : m_vehicles) kv.second->Update(now);
    for (auto& kv : m_remotes)  kv.second->Update(now);
    for (auto& kv : m_npcs)     kv.second->Update(now);
}

void MultiplayerClient::DrawHud()
{
    char buf[160];
    if (!m_cfg.enabled) return;
    if (m_net.IsConnected()) {
        std::snprintf(buf, sizeof(buf),
                      "MP: ONLINE id=%u peers=%u veh=%u npc=%u pk=%u %s",
                      (unsigned)m_localId,
                      (unsigned)m_remotes.size(),
                      (unsigned)m_vehicles.size(),
                      (unsigned)m_npcs.size(),
                      (unsigned)m_pickups.size(),
                      WorldSync::HasReceivedTick() ? "WORLD" : "");
    } else {
        std::snprintf(buf, sizeof(buf), "MP: connecting %s:%u ...",
                      m_cfg.host.c_str(), (unsigned)m_cfg.port);
    }
    wchar wbuf[160];
    for (size_t i = 0;; ++i) {
        wbuf[i] = (wchar)(uint8_t)buf[i];
        if (!buf[i]) break;
    }

    CFont::SetBackgroundOn();
    CFont::SetBackgroundColor(CRGBA(0, 0, 0, 160));
    CFont::SetScale(0.5f, 0.9f);
    CFont::SetPropOn();
    CFont::SetCentreOff();
    CFont::SetJustifyOff();
    CFont::SetRightJustifyOff();
    CFont::SetColor(CRGBA(0, 255, 0, 255));
    CFont::SetFontStyle(FONT_BANK);
    CFont::PrintString(10.0f, 10.0f, wbuf);
}

void MultiplayerClient::ProcessIncoming()
{
    uint8_t tmp[2048];
    for (;;) {
        int n = m_net.Recv(tmp, sizeof(tmp));
        if (n <= 0) break;
        m_recvBuf.insert(m_recvBuf.end(), tmp, tmp + n);
    }

    size_t off = 0;
    while (m_recvBuf.size() - off >= 3) {
        uint16_t payloadLen;
        std::memcpy(&payloadLen, &m_recvBuf[off], 2);
        if (m_recvBuf.size() - off < (size_t)2 + payloadLen) break;
        uint8_t  type    = m_recvBuf[off + 2];
        uint8_t* payload = &m_recvBuf[off + 3];
        uint16_t plen    = payloadLen - 1;
        HandleMessage(type, payload, plen);
        off += 2 + payloadLen;
    }
    if (off > 0) m_recvBuf.erase(m_recvBuf.begin(), m_recvBuf.begin() + off);
}

void MultiplayerClient::HandleMessage(uint8_t type, const uint8_t* payload, uint16_t len)
{
    switch (type) {
    case MSG_WELCOME: {
        if (len >= 2) std::memcpy(&m_localId, payload, 2);
        MP_LOG("WELCOME: localId=%u", (unsigned)m_localId);
        break;
    }
    case MSG_VEH_ASSIGN: {
        if (len < sizeof(VehAssignPayload)) return;
        VehAssignPayload a;
        std::memcpy(&a, payload, sizeof(a));
        if (a.model == m_localVehPendingModel && m_localVehPtr) {
            m_localVehNetId        = a.vehNetId;
            m_localVehPendingModel = 0;
            MP_LOG("VEH_ASSIGN netId=%u model=%u",
                   (unsigned)a.vehNetId, (unsigned)a.model);
            auto vit = m_vehicles.find(a.vehNetId);
            if (vit != m_vehicles.end()) {
                for (auto& kv : m_remotes)
                    kv.second->OnVehicleGone(a.vehNetId);
                if (vit->second->GetVehicle() == m_localVehPtr)
                    vit->second->DetachVehicle();
                delete vit->second;
                m_vehicles.erase(vit);
                MP_LOG("local jack-in: ghost netId=%u handed off to local",
                       (unsigned)a.vehNetId);
            }
        }
        break;
    }
    case MSG_VEH_SNAPSHOT:    HandleVehSnapshot(payload, len);    break;
    case MSG_SNAPSHOT:        HandleSnapshot(payload, len);       break;
    case MSG_PLAYER_LEFT: {
        if (len < 2) return;
        uint16_t pid;
        std::memcpy(&pid, payload, 2);
        auto it = m_remotes.find(pid);
        if (it != m_remotes.end()) {
            it->second->Despawn();
            delete it->second;
            m_remotes.erase(it);
            MP_LOG("remote left id=%u", (unsigned)pid);
        }
        break;
    }
    case MSG_WORLD_TICK: {
        if (len < sizeof(WorldTickPayload)) return;
        WorldTickPayload t;
        std::memcpy(&t, payload, sizeof(t));
        WorldSync::Apply(t);
        break;
    }
    case MSG_NPC_SNAPSHOT:    HandleNpcSnapshot(payload, len);    break;
    case MSG_NPC_REMOVE:      HandleNpcRemove(payload, len);      break;
    case MSG_PICKUP_SPAWN:    HandlePickupSpawn(payload, len);    break;
    case MSG_PICKUP_REMOVE:   HandlePickupRemove(payload, len);   break;
    case MSG_SPAWN_QUERY:     HandleSpawnQuery(payload, len);     break;
    case MSG_NODE_QUERY:      HandleNodeQuery(payload, len);      break;
    default: break;
    }
}

// ---- Spawn oracle (v2.2) -------------------------------------------------
//
// Server can't read the game's road/path data. So when it wants to spawn
// an NPC or a traffic car, it sends MSG_SPAWN_QUERY to one of the
// connected clients ("spawn host") with a hint position. We use the
// engine's CPathFind APIs to find a real, road-valid coord and reply.
// Same idea for picking the next wandering waypoint (MSG_NODE_QUERY) so
// NPCs walk along real sidewalks and cars stay on real roads.
//
// Critically: the SERVER then broadcasts the resulting authoritative
// entity to all clients in AOI - so every player sees the SAME thing,
// not just the one who answered the query.

static void SendOracleReply(TcpClient& net, uint8_t msgType, const void* payload, uint16_t plen)
{
    uint16_t bodyLen = (uint16_t)(1 + plen);
    uint8_t  buf[64];
    std::memcpy(buf, &bodyLen, 2);
    buf[2] = msgType;
    std::memcpy(&buf[3], payload, plen);
    net.Send(buf, 2 + bodyLen);
}

void MultiplayerClient::HandleSpawnQuery(const uint8_t* payload, uint16_t len)
{
    if (len < sizeof(SpawnQueryPayload)) return;
    SpawnQueryPayload q;
    std::memcpy(&q, payload, sizeof(q));

    SpawnReplyPayload r{};
    r.queryId = q.queryId;
    r.ok      = 0;

    if (q.type == PATH_PED) {
        // Engine: find a valid pedestrian-path spawn coord around the hint.
        CVector pos;
        int32   n1 = 0, n2 = 0;
        float   t  = 0.0f;
        bool ok = ThePaths.GeneratePedCreationCoors(
            q.hintX, q.hintY,
            q.minDist, q.maxDist,
            q.minDist, q.maxDist,
            &pos, &n1, &n2, &t, nullptr);
        if (ok) {
            r.ok      = 1;
            r.x       = pos.x;
            r.y       = pos.y;
            r.z       = pos.z;
            r.heading = 0.0f;  // peds will face their first waypoint
        }
    } else { // PATH_CAR
        // Pick a random direction and ask engine for a valid road coord.
        float ang = (float)CGeneral::GetRandomNumberInRange(0.0f, 6.2831853f);
        float dx  = std::cos(ang);
        float dy  = std::sin(ang);
        CVector pos;
        int32   n1 = 0, n2 = 0;
        float   t  = 0.0f;
        float   spawnDist = 0.5f * (q.minDist + q.maxDist);
        bool ok = ThePaths.GenerateCarCreationCoors(
            q.hintX, q.hintY,
            dx, dy,
            spawnDist,
            0.5f,    // angleLimit
            true,    // forward
            &pos, &n1, &n2, &t,
            false);  // ignoreDisabled
        if (ok) {
            r.ok      = 1;
            r.x       = pos.x;
            r.y       = pos.y;
            r.z       = pos.z;
            r.heading = std::atan2(-dx, dy);
        }
    }

    SendOracleReply(m_net, MSG_SPAWN_REPLY, &r, sizeof(r));
}

void MultiplayerClient::HandleNodeQuery(const uint8_t* payload, uint16_t len)
{
    if (len < sizeof(NodeQueryPayload)) return;
    NodeQueryPayload q;
    std::memcpy(&q, payload, sizeof(q));

    NodeReplyPayload r{};
    r.queryId = q.queryId;
    r.ok      = 0;

    // Find the closest path node to where the entity currently is, then
    // ask the engine's wander helper for a sensible next node.
    CVector cur(q.curX, q.curY, q.curZ);
    int32 nodeIdx = ThePaths.FindNodeClosestToCoors(cur, q.type, 80.0f);
    if (nodeIdx < 0) {
        SendOracleReply(m_net, MSG_NODE_REPLY, &r, sizeof(r));
        return;
    }

    CPathNode* lastNode = nullptr;
    CPathNode* nextNode = nullptr;
    uint8 nextDir = 0;
    ThePaths.FindNextNodeWandering(q.type, cur,
                                   &lastNode, &nextNode,
                                   /*curDir*/ (uint8)(CGeneral::GetRandomNumber() & 7),
                                   &nextDir);
    if (nextNode) {
        CVector np = nextNode->GetPosition();
        r.ok = 1;
        r.x  = np.x;
        r.y  = np.y;
        r.z  = np.z;
        // Heading from current pos toward next node.
        float dx = np.x - q.curX;
        float dy = np.y - q.curY;
        r.heading = std::atan2(-dx, dy);
    }

    SendOracleReply(m_net, MSG_NODE_REPLY, &r, sizeof(r));
}

// ---- snapshot handlers --------------------------------------------------

void MultiplayerClient::HandleVehSnapshot(const uint8_t* payload, uint16_t len)
{
    if (len < 2) return;
    uint16_t count;
    std::memcpy(&count, payload, 2);
    const uint8_t* p = payload + 2;
    if (len < 2 + count * sizeof(VehSnapshotEntry)) return;

    uint32_t now = CTimer::GetTimeInMilliseconds();

    std::map<uint16_t, bool> seen;
    for (uint16_t i = 0; i < count; ++i) {
        VehSnapshotEntry e;
        std::memcpy(&e, p, sizeof(e));
        p += sizeof(e);
        seen[e.vehNetId] = true;

        // Local-jacked detection (unchanged from v1).
        if (e.vehNetId == m_localVehNetId &&
            e.ownerPid != 0 && e.ownerPid != m_localId &&
            e.ownerPid != kServerOwnedPid)
        {
            CPlayerPed* lp = FindPlayerPed();
            CVehicle*   lv = m_localVehPtr;
            if (lp && lv) {
                MP_LOG("LOCAL JACKED: vid=%u taken by pid=%u",
                       (unsigned)e.vehNetId, (unsigned)e.ownerPid);
                if (lv->IsBike()) {
                    ((CBike*)lv)->KnockOffRider(WEAPONTYPE_UNARMED, 0,
                                                lp, false);
                } else if (lv->IsCar()) {
                    ((CAutomobile*)lv)->KnockPedOutCar(
                        WEAPONTYPE_UNIDENTIFIED, CAR_DOOR_LF, lp);
                }
                if (m_vehicles.find(e.vehNetId) == m_vehicles.end()) {
                    RemoteVehicle* rv = RemoteVehicle::CreateFromExisting(
                        e.vehNetId, e.model, lv);
                    if (rv) {
                        rv->PushPose(e.x, e.y, e.z, e.heading, now);
                        m_vehicles[e.vehNetId] = rv;
                    }
                }
            }
            m_localVehNetId        = 0;
            m_localVehPendingModel = 0;
            continue;
        }

        if (e.vehNetId == m_localVehNetId) continue;

        RemoteVehicle* rv;
        auto it = m_vehicles.find(e.vehNetId);
        if (it == m_vehicles.end()) {
            rv = new RemoteVehicle(e.vehNetId, e.model);
            if (!rv->Spawn(e.x, e.y, e.z, e.heading)) {
                delete rv; continue;
            }
            m_vehicles[e.vehNetId] = rv;
            MP_LOG("ghost veh spawned netId=%u model=%u owner=%u",
                   (unsigned)e.vehNetId, (unsigned)e.model,
                   (unsigned)e.ownerPid);
        } else {
            rv = it->second;
        }
        rv->PushPose(e.x, e.y, e.z, e.heading, now);
    }

    for (auto it = m_vehicles.begin(); it != m_vehicles.end(); ) {
        if (seen.find(it->first) == seen.end()) {
            uint16_t goneId = it->first;
            MP_LOG("ghost veh despawn netId=%u", (unsigned)goneId);
            for (auto& kv : m_remotes)
                kv.second->OnVehicleGone(goneId);
            it->second->Despawn();
            delete it->second;
            it = m_vehicles.erase(it);
        } else {
            ++it;
        }
    }
}

void MultiplayerClient::HandleSnapshot(const uint8_t* payload, uint16_t len)
{
    if (len < 2) return;
    uint16_t count;
    std::memcpy(&count, payload, 2);
    const uint8_t* p = payload + 2;
    if (len < 2 + count * sizeof(SnapshotEntry)) return;

    uint32_t now = CTimer::GetTimeInMilliseconds();
    for (uint16_t i = 0; i < count; ++i) {
        SnapshotEntry e;
        std::memcpy(&e, p, sizeof(e));
        p += sizeof(e);

        if (e.playerId == m_localId) continue;

        RemotePlayer* rp;
        auto it = m_remotes.find(e.playerId);
        if (it == m_remotes.end()) {
            rp = new RemotePlayer(e.playerId);
            if (!rp->Spawn(e.x, e.y, e.z, e.heading)) {
                delete rp; continue;
            }
            m_remotes[e.playerId] = rp;
            MP_LOG("spawned remote player id=%u", (unsigned)e.playerId);
        } else {
            rp = it->second;
        }

        CVehicle* vehLookup = nullptr;
        if (e.vehNetId != 0) {
            auto vit = m_vehicles.find(e.vehNetId);
            if (vit != m_vehicles.end()) vehLookup = vit->second->GetVehicle();
        }
        rp->PushState(e.x, e.y, e.z, e.heading,
                      e.animState, e.vehNetId, vehLookup, now);
    }
}

void MultiplayerClient::HandleNpcSnapshot(const uint8_t* payload, uint16_t len)
{
    if (len < 2) return;
    uint16_t count;
    std::memcpy(&count, payload, 2);
    const uint8_t* p = payload + 2;
    if (len < 2 + count * sizeof(NpcSnapshotEntry)) return;

    uint32_t now = CTimer::GetTimeInMilliseconds();
    for (uint16_t i = 0; i < count; ++i) {
        NpcSnapshotEntry e;
        std::memcpy(&e, p, sizeof(e));
        p += sizeof(e);

        RemoteNPC* rn;
        auto it = m_npcs.find(e.npcId);
        if (it == m_npcs.end()) {
            rn = new RemoteNPC(e.npcId, e.model);
            if (!rn->Spawn(e.x, e.y, e.z, e.heading)) {
                delete rn; continue;
            }
            m_npcs[e.npcId] = rn;
        } else {
            rn = it->second;
        }
        rn->PushState(e.x, e.y, e.z, e.heading,
                      e.animState, e.health, now);
    }
}

void MultiplayerClient::HandleNpcRemove(const uint8_t* payload, uint16_t len)
{
    if (len < 2) return;
    uint16_t count;
    std::memcpy(&count, payload, 2);
    const uint8_t* p = payload + 2;
    if (len < 2 + count * sizeof(uint16_t)) return;
    for (uint16_t i = 0; i < count; ++i) {
        uint16_t nid;
        std::memcpy(&nid, p, sizeof(nid));
        p += sizeof(nid);
        auto it = m_npcs.find(nid);
        if (it != m_npcs.end()) {
            it->second->Despawn();
            delete it->second;
            m_npcs.erase(it);
        }
    }
}

void MultiplayerClient::HandlePickupSpawn(const uint8_t* payload, uint16_t len)
{
    if (len < 2) return;
    uint16_t count;
    std::memcpy(&count, payload, 2);
    const uint8_t* p = payload + 2;
    if (len < 2 + count * sizeof(PickupSpawnEntry)) return;
    for (uint16_t i = 0; i < count; ++i) {
        PickupSpawnEntry e;
        std::memcpy(&e, p, sizeof(e));
        p += sizeof(e);
        if (m_pickups.find(e.pickupId) != m_pickups.end()) continue;
        RemotePickup* rp = new RemotePickup(e.pickupId, e.model, e.type);
        if (!rp->Spawn(e.x, e.y, e.z)) {
            delete rp; continue;
        }
        m_pickups[e.pickupId] = rp;
    }
}

void MultiplayerClient::HandlePickupRemove(const uint8_t* payload, uint16_t len)
{
    if (len < 2) return;
    uint16_t count;
    std::memcpy(&count, payload, 2);
    const uint8_t* p = payload + 2;
    if (len < 2 + count * sizeof(uint16_t)) return;
    for (uint16_t i = 0; i < count; ++i) {
        uint16_t pkid;
        std::memcpy(&pkid, p, sizeof(pkid));
        p += sizeof(pkid);
        auto it = m_pickups.find(pkid);
        if (it != m_pickups.end()) {
            it->second->Despawn();
            delete it->second;
            m_pickups.erase(it);
        }
    }
}

// ---- local-event detectors ----------------------------------------------

void MultiplayerClient::DetectLocalPickupTakes()
{
    // The engine handles "ped touched pickup" itself; here we only watch
    // for the slot to flip dead and notify the server so the pickup is
    // marked taken (and respawn-timer started) globally.
    for (auto& kv : m_pickups) {
        if (kv.second->DetectLocalTake()) {
            SendPickupTake(kv.first);
            MP_LOG("LOCAL pickup take: id=%u", (unsigned)kv.first);
        }
    }
}

bool MultiplayerClient::GetLocalPlayerPose(float& x, float& y, float& z, float& heading) const
{
    CPlayerPed* p = FindPlayerPed();
    if (!p) return false;
    const CVector& pos = p->GetPosition();
    x = pos.x; y = pos.y; z = pos.z;
    heading = p->m_fRotationCur;
    return true;
}

uint8_t MultiplayerClient::DetectLocalAnimState() const
{
    CPlayerPed* p = FindPlayerPed();
    if (!p) return ANIM_IDLE;
    float speed = p->m_vecMoveSpeed.Magnitude();
    if (speed < 0.02f) return ANIM_IDLE;
    if (speed < 0.10f) return ANIM_WALK;
    if (speed < 0.20f) return ANIM_RUN;
    return ANIM_SPRINT;
}

void MultiplayerClient::DetectLocalVehicleChange()
{
    CPlayerPed* p = FindPlayerPed();
    if (!p) return;
    CVehicle* v = (p->bInVehicle) ? FindPlayerVehicle() : nullptr;

    if (v != m_localVehPtr) {
        if (m_localVehPtr && m_localVehNetId != 0) {
            SendVehLeave(m_localVehNetId);
        }
        m_localVehPtr          = v;
        m_localVehNetId        = 0;
        m_localVehPendingModel = 0;
        m_localVehEnterSentMs  = 0;

        if (v) {
            CVector vp = v->GetPosition();
            uint16_t model = (uint16_t)v->GetModelIndex();
            SendVehEnter(model, vp.x, vp.y, vp.z);
            m_localVehPendingModel = model;
            m_localVehEnterSentMs  = CTimer::GetTimeInMilliseconds();
        }
    } else if (v && m_localVehNetId == 0 && m_localVehPendingModel != 0) {
        uint32_t now = CTimer::GetTimeInMilliseconds();
        if (now - m_localVehEnterSentMs > 1000) {
            CVector vp = v->GetPosition();
            SendVehEnter(m_localVehPendingModel, vp.x, vp.y, vp.z);
            m_localVehEnterSentMs = now;
        }
    }
}

void MultiplayerClient::SendVehEnter(uint16_t model, float x, float y, float z)
{
    VehEnterPayload pl{model, x, y, z};
    uint16_t payloadLen = (uint16_t)(1 + sizeof(pl));
    uint8_t buf[64];
    std::memcpy(buf, &payloadLen, 2);
    buf[2] = MSG_VEH_ENTER;
    std::memcpy(&buf[3], &pl, sizeof(pl));
    m_net.Send(buf, 3 + sizeof(pl));
    MP_LOG("send VEH_ENTER model=%u", (unsigned)model);
}

void MultiplayerClient::SendVehLeave(uint16_t vehNetId)
{
    VehLeavePayload pl{vehNetId};
    uint16_t payloadLen = (uint16_t)(1 + sizeof(pl));
    uint8_t buf[16];
    std::memcpy(buf, &payloadLen, 2);
    buf[2] = MSG_VEH_LEAVE;
    std::memcpy(&buf[3], &pl, sizeof(pl));
    m_net.Send(buf, 3 + sizeof(pl));
    MP_LOG("send VEH_LEAVE netId=%u", (unsigned)vehNetId);
}

void MultiplayerClient::SendPickupTake(uint16_t pickupId)
{
    PickupTakePayload pl{pickupId};
    uint16_t payloadLen = (uint16_t)(1 + sizeof(pl));
    uint8_t buf[16];
    std::memcpy(buf, &payloadLen, 2);
    buf[2] = MSG_PICKUP_TAKE;
    std::memcpy(&buf[3], &pl, sizeof(pl));
    m_net.Send(buf, 3 + sizeof(pl));
}

void MultiplayerClient::SendLocalState()
{
    CPlayerPed* p = FindPlayerPed();
    if (!p) return;

    StatePayload sp;
    sp.vehNetId = 0;

    CVehicle* v = FindPlayerVehicle();
    if (v && p->bInVehicle) {
        const CVector& vp = v->GetPosition();
        sp.x = vp.x; sp.y = vp.y; sp.z = vp.z;
        CVector fwd = v->GetForward();
        sp.heading = std::atan2(-fwd.x, fwd.y);
        sp.animState = ANIM_IDLE;
        sp.vehNetId  = m_localVehNetId;
    } else {
        const CVector& pp = p->GetPosition();
        sp.x = pp.x; sp.y = pp.y; sp.z = pp.z;
        sp.heading = p->m_fRotationCur;
        sp.animState = DetectLocalAnimState();
    }

    uint16_t payloadLen = (uint16_t)(1 + sizeof(StatePayload));
    uint8_t  buf[64];
    std::memcpy(buf, &payloadLen, 2);
    buf[2] = MSG_STATE;
    std::memcpy(&buf[3], &sp, sizeof(sp));
    m_net.Send(buf, 3 + sizeof(sp));
}

std::vector<MultiplayerClient::RadarBlip> MultiplayerClient::GetRadarBlips() const
{
    std::vector<RadarBlip> out;
    out.reserve(m_remotes.size());
    for (const auto& kv : m_remotes) {
        const RemotePlayer* rp = kv.second;
        if (!rp || !rp->IsSpawned()) continue;
        out.push_back({ rp->GetId(), 0.0f, 0.0f, 0.0f });
    }
    return out;
}

} // namespace mp
