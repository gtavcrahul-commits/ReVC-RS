// RemoteVehicle.h - Tracks one vehicle by server-assigned netId. The
// CVehicle* may be either:
//   * "owned": we allocated/spawned it as a ghost (m_owns=true). We delete
//     it on Despawn.
//   * "borrowed": we wrapped a CVehicle that already exists in CWorld
//     (e.g. a local vehicle that just got jacked away from us). The game
//     still owns the entity; we only mirror its pose from the network.
//     m_owns=false; we never delete it.
//
// Ghost vehicles are unlocked + collidable so the local player CAN walk up
// and enter them — that's how we model jacking. The previous remote driver
// is held in the seat for visuals only (its pDriver slot on the CVehicle
// is cleared, so the game doesn't think there's anyone to jack).
#pragma once

#include <cstdint>

class CEntity;
class CVehicle;

namespace mp {

class RemoteVehicle
{
public:
    RemoteVehicle(uint16_t netId, uint16_t model);
    ~RemoteVehicle();

    // Spawn a fresh ghost CAutomobile/CBike at the given pose.
    bool Spawn(float x, float y, float z, float heading);

    // Wrap an existing CVehicle (from local game world) without taking
    // ownership. Used when our local vehicle is jacked away from us; we
    // keep tracking its network pose without deleting the entity.
    static RemoteVehicle* CreateFromExisting(uint16_t netId, uint16_t model,
                                             CVehicle* v);

    // Despawn (CWorld::Remove + delete). If we don't own the CVehicle we
    // just drop the pointer. Safe to call if not spawned.
    void Despawn();

    // Detach and return the CVehicle pointer without deleting it. Used when
    // the local player takes over a ghost via jack-in.
    CVehicle* DetachVehicle();

    // Push a new authoritative pose (snapshot from server).
    void PushPose(float x, float y, float z, float heading, uint32_t timeMs);

    // Update interpolation + sector list. Called every frame.
    void Update(uint32_t nowMs);

    uint16_t  GetNetId()   const { return m_netId; }
    uint16_t  GetModel()   const { return m_model; }
    CVehicle* GetVehicle() const { return m_veh;   }
    bool      IsSpawned()  const { return m_veh != nullptr; }
    bool      Owns()       const { return m_owns;  }

    // Heuristic: when first spawning a ghost vehicle, sweep nearby same-
    // model local CVehicles (parked traffic etc.) and remove them so we
    // don't end up with two visually-identical bikes/cars overlapping.
    static void RemoveNearbyDuplicates(uint16_t model, float x, float y,
                                       float z, float radius,
                                       CVehicle* exclude);

private:
    static void Reposition(::CEntity* e, float x, float y, float z, float heading);

    uint16_t  m_netId;
    uint16_t  m_model;
    CVehicle* m_veh;
    bool      m_owns;     // do we delete m_veh on Despawn?

    float     m_prevX, m_prevY, m_prevZ, m_prevHeading;
    float     m_targetX, m_targetY, m_targetZ, m_targetHeading;
    uint32_t  m_prevTimeMs;
    uint32_t  m_targetTimeMs;
};

} // namespace mp
