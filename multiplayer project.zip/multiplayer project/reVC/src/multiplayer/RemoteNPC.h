// RemoteNPC.h - A server-driven pedestrian NPC.
//
// Functionally similar to RemotePlayer (CCivilianPed wrapper, smoothed
// interpolation, anim swap), but:
//   - Identified by a SERVER-assigned npcId (independent of player IDs).
//   - Uses whatever model the server picks (any MI_* civilian).
//   - Never has a vehicle (v2 NPC traffic uses RemoteVehicle ghosts
//     marked with ownerPid==0xFFFF).
//   - Cleared by MSG_NPC_REMOVE; lives only as long as it's in AOI.
//
#pragma once

#include "Protocol.h"

class CEntity;
class CPed;

namespace mp {

class RemoteNPC
{
public:
    RemoteNPC(uint16_t npcId, uint16_t model);
    ~RemoteNPC();

    // Spawn underlying CCivilianPed at given pose. Returns false if the
    // model can't be loaded (caller must not retain this RemoteNPC if so).
    bool Spawn(float x, float y, float z, float heading);

    // Remove ped from world and free memory.
    void Despawn();

    // Push the latest snapshot from the server. Cheap; just buffers
    // prev/target poses and stores anim/health for the next Update().
    void PushState(float x, float y, float z, float heading,
                   uint8_t animState, uint8_t health, uint32_t timeMs);

    // Per-frame interpolation tick.
    void Update(uint32_t nowMs);

    uint16_t GetId() const     { return m_id; }
    bool     IsSpawned() const { return m_ped != nullptr; }

private:
    void ApplyAnim(uint8_t animState);

    static void Reposition(::CEntity* e, float x, float y, float z, float heading);

    uint16_t   m_id;
    uint16_t   m_model;
    CPed*      m_ped;

    float      m_prevX, m_prevY, m_prevZ, m_prevHeading;
    float      m_targetX, m_targetY, m_targetZ, m_targetHeading;
    uint32_t   m_prevTimeMs;
    uint32_t   m_targetTimeMs;

    uint8_t    m_curAnim;
    uint8_t    m_curHealth;
};

} // namespace mp
