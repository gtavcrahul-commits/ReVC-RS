// RemotePickup.cpp - thin wrapper around the engine's CPickups pool.
#include "common.h"

#include "RemotePickup.h"

#include "Pickups.h"
#include "Streaming.h"
#include "ModelInfo.h"
#include "Vector.h"

namespace mp {

RemotePickup::RemotePickup(uint16_t pickupId, uint16_t model, uint8_t type)
    : m_id(pickupId), m_model(model), m_type(type),
      m_engineSlot(-1), m_aliveExpected(false), m_takenLocally(false) {}

RemotePickup::~RemotePickup() { Despawn(); }

bool RemotePickup::Spawn(float x, float y, float z)
{
    if (m_engineSlot >= 0) return true;

    int modelIdx = (int)m_model;
    if (!CStreaming::HasModelLoaded(modelIdx)) {
        CStreaming::RequestModel(modelIdx, STREAMFLAGS_DONT_REMOVE);
        CStreaming::LoadAllRequestedModels(false);
    }
    if (!CStreaming::HasModelLoaded(modelIdx))
        return false;

    CVector pos(x, y, z);
    int32 slot = CPickups::GenerateNewOne(pos, (uint32)modelIdx,
                                          (uint8)m_type, 1, 0, false, nil);
    if (slot < 0) return false;

    m_engineSlot   = slot;
    m_aliveExpected = true;
    return true;
}

void RemotePickup::Despawn()
{
    if (m_engineSlot >= 0) {
        // CPickups doesn't expose a clean "remove by slot" public API
        // in vanilla reVC, but the slot object's m_eType==PICKUP_NONE
        // is what the engine uses to mark dead pickups. Set it.
        CPickups::aPickUps[m_engineSlot].m_eType = PICKUP_NONE;
        m_engineSlot   = -1;
        m_aliveExpected = false;
    }
}

bool RemotePickup::IsAlive() const
{
    if (m_engineSlot < 0) return false;
    return CPickups::aPickUps[m_engineSlot].m_eType != PICKUP_NONE;
}

bool RemotePickup::DetectLocalTake()
{
    if (!m_aliveExpected) return false;
    if (m_engineSlot < 0) return false;
    if (IsAlive())        return false;

    // Engine pool says this slot is dead but we hadn't been told yet by
    // the server. The only thing that clears a pickup locally is the
    // local player walking through it.
    m_aliveExpected = false;
    m_takenLocally  = true;
    m_engineSlot    = -1;
    return true;
}

} // namespace mp
