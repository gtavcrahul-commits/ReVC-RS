// RemoteNPC.cpp - Server-driven pedestrian. Mirrors RemotePlayer's
// approach for spawning + interpolation, but is keyed on npcId, not pid.
#include "common.h"

#include "RemoteNPC.h"

#include "General.h"
#include "ModelIndices.h"
#include "ModelInfo.h"
#include "World.h"
#include "Streaming.h"
#include "Pools.h"
#include "Ped.h"
#include "PedType.h"
#include "CivilianPed.h"
#include "AnimationId.h"
#include "AnimManager.h"
#include "AnimBlendAssociation.h"
#include "AnimBlendAssocGroup.h"
#include "RpAnimBlend.h"
#include "Vector.h"
#include "Timer.h"

namespace mp {

RemoteNPC::RemoteNPC(uint16_t npcId, uint16_t model)
    : m_id(npcId), m_model(model), m_ped(nullptr),
      m_prevX(0), m_prevY(0), m_prevZ(0), m_prevHeading(0),
      m_targetX(0), m_targetY(0), m_targetZ(0), m_targetHeading(0),
      m_prevTimeMs(0), m_targetTimeMs(0),
      m_curAnim(ANIM_IDLE), m_curHealth(100) {}

RemoteNPC::~RemoteNPC() { Despawn(); }

void RemoteNPC::Reposition(CEntity* e, float x, float y, float z, float h)
{
    if (!e) return;
    CWorld::Remove(e);
    CVector pos(x, y, z);
    e->SetPosition(pos);
    e->SetOrientation(0.0f, 0.0f, h);
    CWorld::Add(e);
}

bool RemoteNPC::Spawn(float x, float y, float z, float heading)
{
    if (m_ped) return true;

    int modelIdx = (int)m_model;
    if (!CStreaming::HasModelLoaded(modelIdx)) {
        CStreaming::RequestModel(modelIdx, STREAMFLAGS_DONT_REMOVE);
        CStreaming::LoadAllRequestedModels(false);
    }
    if (!CStreaming::HasModelLoaded(modelIdx))
        return false;

    CCivilianPed* ped = new CCivilianPed(PEDTYPE_CIVMALE, modelIdx);
    if (!ped) return false;

    CVector pos(x, y, z);
    ped->SetPosition(pos);
    ped->SetOrientation(0.0f, 0.0f, heading);
    ped->m_fRotationCur  = heading;
    ped->m_fRotationDest = heading;
    ped->SetPedState(PED_IDLE);
    // Server owns the NPC's brain - kill local AI so nothing
    // local gives this ped its own goals.
    ped->bRespondsToThreats   = false;
    ped->bStreamingDontDelete = true;

    CWorld::Add(ped);
    m_ped = ped;

    m_prevX = m_targetX = x;
    m_prevY = m_targetY = y;
    m_prevZ = m_targetZ = z;
    m_prevHeading = m_targetHeading = heading;
    m_prevTimeMs = m_targetTimeMs = CTimer::GetTimeInMilliseconds();
    return true;
}

void RemoteNPC::Despawn()
{
    if (m_ped) {
        CWorld::Remove(m_ped);
        delete m_ped;
        m_ped = nullptr;
    }
}

void RemoteNPC::PushState(float x, float y, float z, float heading,
                          uint8_t animState, uint8_t health, uint32_t timeMs)
{
    if (!m_ped) {
        Spawn(x, y, z, heading);
        if (!m_ped) return;
    }

    m_prevX       = m_targetX;
    m_prevY       = m_targetY;
    m_prevZ       = m_targetZ;
    m_prevHeading = m_targetHeading;
    m_prevTimeMs  = m_targetTimeMs;

    m_targetX       = x;
    m_targetY       = y;
    m_targetZ       = z;
    m_targetHeading = heading;
    m_targetTimeMs  = timeMs;

    if (animState != m_curAnim) {
        ApplyAnim(animState);
        m_curAnim = animState;
    }
    m_curHealth = health;
}

static float LerpAngle(float a, float b, float t)
{
    float diff = b - a;
    while (diff >  3.14159265f) diff -= 6.28318530f;
    while (diff < -3.14159265f) diff += 6.28318530f;
    return a + diff * t;
}

void RemoteNPC::Update(uint32_t nowMs)
{
    if (!m_ped) return;

    float t = 1.0f;
    if (m_targetTimeMs > m_prevTimeMs) {
        t = (float)(nowMs - m_prevTimeMs) / (float)(m_targetTimeMs - m_prevTimeMs);
        if (t < 0.0f) t = 0.0f;
        if (t > 1.5f) t = 1.5f;
    }
    float x = m_prevX + (m_targetX - m_prevX) * t;
    float y = m_prevY + (m_targetY - m_prevY) * t;
    float z = m_prevZ + (m_targetZ - m_prevZ) * t;
    float h = LerpAngle(m_prevHeading, m_targetHeading, t);

    Reposition(m_ped, x, y, z, h);
    m_ped->m_fRotationCur  = h;
    m_ped->m_fRotationDest = h;
}

void RemoteNPC::ApplyAnim(uint8_t animState)
{
    if (!m_ped) return;
    AnimationId animId;
    switch (animState) {
        case ANIM_WALK:   animId = ::ANIM_STD_WALK;        break;
        case ANIM_RUN:    animId = ::ANIM_STD_RUN;         break;
        case ANIM_SPRINT: animId = ::ANIM_STD_RUNFAST;     break;
        case ANIM_JUMP:   animId = ::ANIM_STD_JUMP_LAUNCH; break;
        case ANIM_IDLE:
        default:          animId = ::ANIM_STD_IDLE;        break;
    }
    CAnimBlendAssociation* assoc =
        CAnimManager::BlendAnimation(m_ped->GetClump(),
                                     ASSOCGRP_STD, animId, 4.0f);
    if (assoc) assoc->flags |= ASSOC_REPEAT;
}

} // namespace mp
