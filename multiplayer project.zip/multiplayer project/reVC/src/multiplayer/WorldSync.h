// WorldSync.h - Apply server-authoritative time + weather to the engine.
//
// The server pushes MSG_WORLD_TICK roughly every second with the current
// (hour, minute, dayOfWeek) and a (oldWeather, newWeather, interp) pair.
// This module pokes those values directly into CClock/CWeather so all
// connected clients see the same sky and time of day.
//
// Notes:
//   - We never let the engine roll the clock or roll weather forward
//     while connected; only WorldSync writes those globals.
//   - Smoothing: minute hand moves only when the server delivers a new
//     value, so the in-game clock effectively quantises to ~1 second
//     granularity. That's fine for HUD/lighting purposes.
//
#pragma once

#include "Protocol.h"

namespace mp {

class WorldSync
{
public:
    // Apply the server's tick. Cheap and idempotent - safe to call
    // every time a MSG_WORLD_TICK is received.
    static void Apply(const WorldTickPayload& tick);

    // Reset internal "have we ever applied" flag, so a fresh server
    // tick after disconnect/reconnect always wins.
    static void Reset();

    // Has at least one tick been received since connect/reset?
    static bool HasReceivedTick();
};

} // namespace mp
