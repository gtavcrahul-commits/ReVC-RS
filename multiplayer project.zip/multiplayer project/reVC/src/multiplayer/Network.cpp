// Network.cpp - POSIX TCP socket implementation.
#include "Network.h"

#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <cstring>

namespace mp {

TcpClient::TcpClient() : m_socket(-1) {}

TcpClient::~TcpClient() { Disconnect(); }

bool TcpClient::Connect(const std::string& host, uint16_t port)
{
    Disconnect();

    addrinfo hints; std::memset(&hints, 0, sizeof(hints));
    hints.ai_family   = AF_INET;
    hints.ai_socktype = SOCK_STREAM;

    char portStr[8];
    std::snprintf(portStr, sizeof(portStr), "%u", port);

    addrinfo* result = nullptr;
    if (getaddrinfo(host.c_str(), portStr, &hints, &result) != 0 || !result) {
        return false;
    }

    int s = ::socket(result->ai_family, result->ai_socktype, result->ai_protocol);
    if (s < 0) { freeaddrinfo(result); return false; }

    // Blocking connect (one-time during join). Then we set non-blocking.
    if (::connect(s, result->ai_addr, result->ai_addrlen) < 0) {
        ::close(s);
        freeaddrinfo(result);
        return false;
    }
    freeaddrinfo(result);

    // Disable Nagle - we want low latency state updates.
    int one = 1;
    setsockopt(s, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));

    // Non-blocking I/O.
    int flags = fcntl(s, F_GETFL, 0);
    fcntl(s, F_SETFL, flags | O_NONBLOCK);

    m_socket = s;
    return true;
}

void TcpClient::Disconnect()
{
    if (m_socket >= 0) {
        ::shutdown(m_socket, SHUT_RDWR);
        ::close(m_socket);
        m_socket = -1;
    }
}

int TcpClient::Send(const void* data, size_t len)
{
    if (m_socket < 0) return -1;
    ssize_t n = ::send(m_socket, data, len, MSG_NOSIGNAL);
    if (n < 0) {
        if (errno == EAGAIN || errno == EWOULDBLOCK) return 0;
        Disconnect();
        return -1;
    }
    return (int)n;
}

int TcpClient::Recv(void* buffer, size_t maxLen)
{
    if (m_socket < 0) return -1;
    ssize_t n = ::recv(m_socket, buffer, maxLen, 0);
    if (n == 0) { Disconnect(); return -1; }
    if (n < 0) {
        if (errno == EAGAIN || errno == EWOULDBLOCK) return 0;
        Disconnect();
        return -1;
    }
    return (int)n;
}

} // namespace mp
