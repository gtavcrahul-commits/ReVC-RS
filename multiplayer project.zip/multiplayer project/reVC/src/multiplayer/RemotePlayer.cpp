// RemotePlayer.cpp - Spawn a CCivilianPed and drive it from network state.
// Vehicles are managed by RemoteVehicle (server netIds); we only attach our
// ped to whatever CVehicle pointer the lookup gives us.
#include "common.h"

#include "RemotePlayer.h"

#include "General.h"
#include "ModelIndices.h"
#include "ModelInfo.h"
#include "World.h"
#include "Streaming.h"
#include "Pools.h"
#include "Ped.h"
#include "PedType.h"
#include "CivilianPed.h"
#include "Vehicle.h"
#include "AnimationId.h"
#include "AnimManager.h"
#include "AnimBlendAssociation.h"
#include "AnimBlendAssocGroup.h"
#include "RpAnimBlend.h"
#include "Vector.h"
#include "Timer.h"

namespace mp {

static const int kRemotePlayerModel = MI_MALE01;

RemotePlayer::RemotePlayer(uint16_t id)
    : m_id(id), m_ped(nullptr),
      m_attachedVeh(nullptr), m_curVehNetId(0),
      m_prevX(0), m_prevY(0), m_prevZ(0), m_prevHeading(0),
      m_targetX(0), m_targetY(0), m_targetZ(0), m_targetHeading(0),
      m_prevTimeMs(0), m_targetTimeMs(0), m_curAnim(mp::ANIM_IDLE) {}

RemotePlayer::~RemotePlayer() { Despawn(); }

// ---- helpers --------------------------------------------------------------

void RemotePlayer::Reposition(CEntity* e, float x, float y, float z, float h)
{
    if (!e) return;
    CWorld::Remove(e);
    CVector pos(x, y, z);
    e->SetPosition(pos);
    e->SetOrientation(0.0f, 0.0f, h);
    CWorld::Add(e);
}

void RemotePlayer::AttachToVehicle(CVehicle* v)
{
    if (!m_ped || !v) return;
    if (m_attachedVeh == v) return;

    DetachFromVehicle();
    // Warp the ped into the seat. We deliberately do NOT use the AI enter
    // sequence - that would require running ped tasks which we don't drive.
    m_ped->WarpPedIntoCar(v);
    // Critical: clear the seat slot AFTER warping. The ped is still rendered
    // at the seat (we re-position it each frame), but as far as the game's
    // enter/jack logic is concerned the seat is empty -- so when the LOCAL
    // player walks up and enters, they take the seat normally instead of
    // trying to "jack" our ghost ped (which would crash because the ghost
    // ped has no AI task state).
    if (v->pDriver == m_ped) v->pDriver = nullptr;
    m_ped->bUsesCollision = false;
    m_attachedVeh = v;
}

void RemotePlayer::OnVehicleGone(uint16_t vehNetId)
{
    if (m_curVehNetId != vehNetId) return;
    // Drop the dangling pointer FIRST, then run the rest of detach. We can't
    // call DetachFromVehicle's pDriver-clear path because m_attachedVeh may
    // already have been deleted; just zero everything.
    m_attachedVeh = nullptr;
    m_curVehNetId = 0;
    if (m_ped) {
        m_ped->bInVehicle    = false;
        m_ped->m_pMyVehicle  = nullptr;
        m_ped->bUsesCollision = true;
        m_ped->SetPedState(PED_IDLE);
    }
}

void RemotePlayer::DetachFromVehicle()
{
    if (!m_ped) return;
    if (m_attachedVeh) {
        if (m_attachedVeh->pDriver == m_ped) m_attachedVeh->pDriver = nullptr;
        m_attachedVeh = nullptr;
    }
    m_ped->bInVehicle    = false;
    m_ped->m_pMyVehicle  = nullptr;
    m_ped->bUsesCollision = true;
    m_ped->SetPedState(PED_IDLE);
}

// ---- public API -----------------------------------------------------------

bool RemotePlayer::Spawn(float x, float y, float z, float heading)
{
    if (m_ped) return true;

    if (!CStreaming::HasModelLoaded(kRemotePlayerModel)) {
        CStreaming::RequestModel(kRemotePlayerModel, STREAMFLAGS_DONT_REMOVE);
        CStreaming::LoadAllRequestedModels(false);
    }
    if (!CStreaming::HasModelLoaded(kRemotePlayerModel))
        return false;

    CCivilianPed* ped = new CCivilianPed(PEDTYPE_CIVMALE, kRemotePlayerModel);
    if (!ped) return false;

    CVector pos(x, y, z);
    ped->SetPosition(pos);
    ped->SetOrientation(0.0f, 0.0f, heading);
    ped->m_fRotationCur  = heading;
    ped->m_fRotationDest = heading;
    ped->SetPedState(PED_IDLE);
    ped->bRespondsToThreats   = false;
    ped->bStreamingDontDelete = true;

    CWorld::Add(ped);
    m_ped = ped;

    m_prevX = m_targetX = x;
    m_prevY = m_targetY = y;
    m_prevZ = m_targetZ = z;
    m_prevHeading = m_targetHeading = heading;
    m_prevTimeMs = m_targetTimeMs = CTimer::GetTimeInMilliseconds();
    return true;
}

void RemotePlayer::Despawn()
{
    DetachFromVehicle();
    if (m_ped) {
        CWorld::Remove(m_ped);
        delete m_ped;
        m_ped = nullptr;
    }
}

void RemotePlayer::PushState(float x, float y, float z, float heading,
                             uint8_t animState, uint16_t vehNetId,
                             CVehicle* vehLookup, uint32_t timeMs)
{
    if (!m_ped) {
        Spawn(x, y, z, heading);
        if (!m_ped) return;
    }

    // Vehicle transition handling.
    if (vehNetId != m_curVehNetId) {
        if (vehNetId == 0) {
            DetachFromVehicle();
            m_curVehNetId = 0;
        } else if (vehLookup) {
            AttachToVehicle(vehLookup);
            m_curVehNetId = vehNetId;
        }
        // If vehNetId != 0 but vehLookup is null, the vehicle snapshot
        // hasn't arrived yet. We leave the ped on foot until it does, then
        // attach next time PushState comes through.
    } else if (vehNetId != 0 && vehLookup && m_attachedVeh != vehLookup) {
        // Same netId but the underlying CVehicle pointer changed
        // (re-spawned). Re-attach.
        AttachToVehicle(vehLookup);
    }

    m_prevX       = m_targetX;
    m_prevY       = m_targetY;
    m_prevZ       = m_targetZ;
    m_prevHeading = m_targetHeading;
    m_prevTimeMs  = m_targetTimeMs;

    m_targetX       = x;
    m_targetY       = y;
    m_targetZ       = z;
    m_targetHeading = heading;
    m_targetTimeMs  = timeMs;

    if (m_curVehNetId == 0 && animState != m_curAnim) {
        ApplyAnim(animState);
        m_curAnim = animState;
    }
}

static float LerpAngle(float a, float b, float t)
{
    float diff = b - a;
    while (diff >  3.14159265f) diff -= 6.28318530f;
    while (diff < -3.14159265f) diff += 6.28318530f;
    return a + diff * t;
}

void RemotePlayer::Update(uint32_t nowMs)
{
    if (!m_ped) return;

    float t = 1.0f;
    if (m_targetTimeMs > m_prevTimeMs) {
        t = (float)(nowMs - m_prevTimeMs) / (float)(m_targetTimeMs - m_prevTimeMs);
        if (t < 0.0f) t = 0.0f;
        if (t > 1.5f) t = 1.5f;
    }
    float x = m_prevX + (m_targetX - m_prevX) * t;
    float y = m_prevY + (m_targetY - m_prevY) * t;
    float z = m_prevZ + (m_targetZ - m_prevZ) * t;
    float h = LerpAngle(m_prevHeading, m_targetHeading, t);

    if (m_attachedVeh) {
        // Mirror ped pose to the vehicle's actual pose so the warped-in ped
        // renders at the correct seat even if interpolation drifts. The
        // vehicle itself is being moved by RemoteVehicle::Update().
        CVector vp = m_attachedVeh->GetPosition();
        Reposition(m_ped, vp.x, vp.y, vp.z, h);
    } else {
        Reposition(m_ped, x, y, z, h);
    }
    m_ped->m_fRotationCur  = h;
    m_ped->m_fRotationDest = h;
}

void RemotePlayer::ApplyAnim(uint8_t animState)
{
    if (!m_ped) return;

    AnimationId animId;
    switch (animState) {
        case mp::ANIM_WALK:   animId = ::ANIM_STD_WALK;        break;
        case mp::ANIM_RUN:    animId = ::ANIM_STD_RUN;         break;
        case mp::ANIM_SPRINT: animId = ::ANIM_STD_RUNFAST;     break;
        case mp::ANIM_JUMP:   animId = ::ANIM_STD_JUMP_LAUNCH; break;
        case mp::ANIM_IDLE:
        default:              animId = ::ANIM_STD_IDLE;        break;
    }

    CAnimBlendAssociation* assoc =
        CAnimManager::BlendAnimation(m_ped->GetClump(),
                                     ASSOCGRP_STD, animId, 4.0f);
    if (assoc) {
        assoc->flags |= ASSOC_REPEAT;
    }
}

} // namespace mp
