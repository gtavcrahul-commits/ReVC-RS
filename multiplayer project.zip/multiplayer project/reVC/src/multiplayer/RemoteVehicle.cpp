// RemoteVehicle.cpp - Implementation of the network-authoritative ghost
// vehicle. See header for design notes.
#include "common.h"

#include "RemoteVehicle.h"

#include "ModelInfo.h"
#include "World.h"
#include "Streaming.h"
#include "Pools.h"
#include "Vehicle.h"
#include "Automobile.h"
#include "Bike.h"
#include "PlayerInfo.h"
#include "Vector.h"
#include "Timer.h"

namespace mp {

// ---- helpers --------------------------------------------------------------

void RemoteVehicle::Reposition(CEntity* e, float x, float y, float z, float h)
{
    if (!e) return;
    CWorld::Remove(e);
    CVector pos(x, y, z);
    e->SetPosition(pos);
    e->SetOrientation(0.0f, 0.0f, h);
    CWorld::Add(e);
}

void RemoteVehicle::RemoveNearbyDuplicates(uint16_t model, float x, float y,
                                           float z, float radius,
                                           CVehicle* exclude)
{
    CVehiclePool* pool = CPools::GetVehiclePool();
    if (!pool) return;
    CVehicle* localPlayerVeh = FindPlayerVehicle();
    int n = pool->GetSize();
    float r2 = radius * radius;
    for (int i = 0; i < n; i++) {
        CVehicle* v = pool->GetSlot(i);
        if (!v) continue;
        if (v == exclude)        continue;
        if (v == localPlayerVeh) continue;        // never destroy player car
        if (v->GetModelIndex() != (int)model) continue;
        if (v->pDriver != nullptr) continue;       // someone's driving
        CVector vp = v->GetPosition();
        float dx = vp.x - x, dy = vp.y - y, dz = vp.z - z;
        if (dx*dx + dy*dy + dz*dz < r2) {
            CWorld::Remove(v);
            delete v;
        }
    }
}

// ---- ctor / dtor ----------------------------------------------------------

RemoteVehicle::RemoteVehicle(uint16_t netId, uint16_t model)
    : m_netId(netId), m_model(model), m_veh(nullptr), m_owns(true),
      m_prevX(0), m_prevY(0), m_prevZ(0), m_prevHeading(0),
      m_targetX(0), m_targetY(0), m_targetZ(0), m_targetHeading(0),
      m_prevTimeMs(0), m_targetTimeMs(0) {}

RemoteVehicle::~RemoteVehicle() { Despawn(); }

RemoteVehicle* RemoteVehicle::CreateFromExisting(uint16_t netId, uint16_t model,
                                                 CVehicle* v)
{
    if (!v) return nullptr;
    RemoteVehicle* rv = new RemoteVehicle(netId, model);
    rv->m_veh  = v;
    rv->m_owns = false;     // we did NOT allocate this; do not delete
    CVector pos = v->GetPosition();
    rv->m_prevX = rv->m_targetX = pos.x;
    rv->m_prevY = rv->m_targetY = pos.y;
    rv->m_prevZ = rv->m_targetZ = pos.z;
    rv->m_prevHeading = rv->m_targetHeading = 0.0f;
    rv->m_prevTimeMs  = rv->m_targetTimeMs  = CTimer::GetTimeInMilliseconds();
    return rv;
}

CVehicle* RemoteVehicle::DetachVehicle()
{
    CVehicle* v = m_veh;
    m_veh  = nullptr;
    m_owns = false;
    return v;
}

// ---- public API -----------------------------------------------------------

bool RemoteVehicle::Spawn(float x, float y, float z, float heading)
{
    if (m_veh) return true;

    if (!CStreaming::HasModelLoaded(m_model)) {
        CStreaming::RequestModel(m_model, STREAMFLAGS_DONT_REMOVE);
        CStreaming::LoadAllRequestedModels(false);
    }
    if (!CStreaming::HasModelLoaded(m_model))
        return false;

    // Wipe out any local traffic copies of the same model right where we
    // appear, to prevent the "two bikes overlap" visual.
    RemoveNearbyDuplicates(m_model, x, y, z, 4.0f, nullptr);

    CVehicle* v;
    if (CModelInfo::IsBikeModel(m_model))
        v = new CBike(m_model, MISSION_VEHICLE);
    else
        v = new CAutomobile(m_model, MISSION_VEHICLE);
    if (!v) return false;

    CVector pos(x, y, z);
    v->SetPosition(pos);
    v->SetOrientation(0.0f, 0.0f, heading);
    v->SetStatus(STATUS_PHYSICS);
    v->bEngineOn          = true;

    // Ghost vehicles MUST be enterable -- that's how jacking works in MP.
    // The ghost ped is warped into the seat for visuals only; the CVehicle's
    // pDriver slot is cleared so the local enter sequence runs as a normal
    // (no-jack) entry rather than triggering jack-the-driver code paths
    // (which would crash because our ghost driver has no task state).
    v->bIsLocked          = false;
    v->m_nDoorLock        = CARLOCK_UNLOCKED;
    v->bUsesCollision     = true;

    // Tell the streaming/cleanup pass not to delete this entity.
    v->bStreamingDontDelete = true;

    CWorld::Add(v);

    m_veh = v;
    m_prevX = m_targetX = x;
    m_prevY = m_targetY = y;
    m_prevZ = m_targetZ = z;
    m_prevHeading = m_targetHeading = heading;
    m_prevTimeMs = m_targetTimeMs = CTimer::GetTimeInMilliseconds();
    return true;
}

void RemoteVehicle::Despawn()
{
    if (!m_veh) return;
    if (m_owns) {
        if (m_veh->pDriver) m_veh->pDriver = nullptr;
        CWorld::Remove(m_veh);
        delete m_veh;
    }
    // For borrowed CVehicles, the local game still owns and ticks them.
    m_veh = nullptr;
}

void RemoteVehicle::PushPose(float x, float y, float z, float heading,
                             uint32_t timeMs)
{
    if (!m_veh) {
        Spawn(x, y, z, heading);
        return;
    }
    m_prevX       = m_targetX;
    m_prevY       = m_targetY;
    m_prevZ       = m_targetZ;
    m_prevHeading = m_targetHeading;
    m_prevTimeMs  = m_targetTimeMs;

    m_targetX       = x;
    m_targetY       = y;
    m_targetZ       = z;
    m_targetHeading = heading;
    m_targetTimeMs  = timeMs;
}

static float LerpAngleVeh(float a, float b, float t)
{
    float diff = b - a;
    while (diff >  3.14159265f) diff -= 6.28318530f;
    while (diff < -3.14159265f) diff += 6.28318530f;
    return a + diff * t;
}

void RemoteVehicle::Update(uint32_t nowMs)
{
    if (!m_veh) return;

    float t = 1.0f;
    if (m_targetTimeMs > m_prevTimeMs) {
        t = (float)(nowMs - m_prevTimeMs) /
            (float)(m_targetTimeMs - m_prevTimeMs);
        if (t < 0.0f) t = 0.0f;
        if (t > 1.5f) t = 1.5f;
    }
    float x = m_prevX + (m_targetX - m_prevX) * t;
    float y = m_prevY + (m_targetY - m_prevY) * t;
    float z = m_prevZ + (m_targetZ - m_prevZ) * t;
    float h = LerpAngleVeh(m_prevHeading, m_targetHeading, t);

    Reposition(m_veh, x, y, z, h);
    m_veh->m_fSteerAngle = 0.0f;
}

} // namespace mp
