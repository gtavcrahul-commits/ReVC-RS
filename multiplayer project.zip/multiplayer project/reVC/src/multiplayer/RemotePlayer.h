// RemotePlayer.h - Wraps a CCivilianPed used to render another connected
// player. Vehicles are managed separately by RemoteVehicle (server-assigned
// netIds). When the remote player is in a vehicle, RemotePlayer just warps
// its ped into that vehicle's seat; it does NOT spawn vehicles itself.
#pragma once

#include "Protocol.h"

class CEntity;
class CPed;
class CVehicle;

namespace mp {

class RemotePlayer
{
public:
    RemotePlayer(uint16_t id);
    ~RemotePlayer();

    // Spawn the underlying CPed at the given foot pose.
    bool Spawn(float x, float y, float z, float heading);

    // Remove ped from world. Detaches from vehicle first if attached.
    void Despawn();

    // Push a new authoritative state.
    //   x/y/z/heading describe the VEHICLE pos if vehNetId != 0, else the ped.
    //   vehLookup     : if vehNetId != 0, points to the CVehicle to attach to
    //                   (caller looks it up in the RemoteVehicle map). May be
    //                   nullptr if the vehicle isn't known yet, in which case
    //                   we just buffer the state until it appears.
    void PushState(float x, float y, float z, float heading,
                   uint8_t animState, uint16_t vehNetId,
                   CVehicle* vehLookup, uint32_t timeMs);

    // Tick interpolation. Called every frame. vehLookup must be the same
    // pointer the most recent PushState produced (or nullptr if unknown).
    void Update(uint32_t nowMs);

    // Called when a vehicle the remote player is currently riding gets
    // despawned (so we drop the dangling pointer before it's deleted).
    void OnVehicleGone(uint16_t vehNetId);

    uint16_t GetId() const { return m_id; }
    bool     IsSpawned() const { return m_ped != nullptr; }
    uint16_t GetCurVehNetId() const { return m_curVehNetId; }

private:
    void ApplyAnim(uint8_t animState);
    void AttachToVehicle(CVehicle* v);
    void DetachFromVehicle();

    static void Reposition(::CEntity* e, float x, float y, float z, float heading);

    uint16_t   m_id;
    CPed*      m_ped;

    // Vehicle attachment (we never own vehicles - just hold a weak pointer
    // to a RemoteVehicle's CVehicle while the remote player is inside it).
    CVehicle*  m_attachedVeh;
    uint16_t   m_curVehNetId;     // 0 = on foot

    // Interpolation snapshot of THIS player's pose. When in vehicle this
    // mirrors the vehicle's pose so the warped-in ped renders at the seat.
    float      m_prevX, m_prevY, m_prevZ, m_prevHeading;
    float      m_targetX, m_targetY, m_targetZ, m_targetHeading;
    uint32_t   m_prevTimeMs;
    uint32_t   m_targetTimeMs;

    uint8_t    m_curAnim;
};

} // namespace mp
