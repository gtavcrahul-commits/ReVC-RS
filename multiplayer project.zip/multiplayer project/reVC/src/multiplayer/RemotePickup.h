// RemotePickup.h - One server-managed pickup mirrored locally as a
// CPickups slot. Spawned via MSG_PICKUP_SPAWN, removed via
// MSG_PICKUP_REMOVE. The local engine handles the actual "ped touched
// it" detection; we hook that to send MSG_PICKUP_TAKE upstream.
//
// Tracking is intentionally simple: we remember the engine slot index
// returned by CPickups::GenerateNewOne so we can free the same slot
// when the server tells us the pickup is gone, and so we can detect
// "this slot is no longer alive" each frame to know the local player
// just collected it.
//
#pragma once

#include "Protocol.h"

namespace mp {

class RemotePickup
{
public:
    RemotePickup(uint16_t pickupId, uint16_t model, uint8_t type);
    ~RemotePickup();

    // Spawn into the engine's CPickups pool. Returns false if the
    // model can't be loaded.
    bool Spawn(float x, float y, float z);

    // Forcibly remove from the engine pool (server said it's gone).
    void Despawn();

    // True if local engine still considers this pickup alive.
    // When this transitions alive -> dead and the server hasn't
    // already told us, the local player just picked it up.
    bool IsAlive() const;

    uint16_t GetId() const         { return m_id; }
    int32_t  GetEngineSlot() const { return m_engineSlot; }
    bool     WasTakenLocally() const { return m_takenLocally; }
    void     ClearTakenLocally()     { m_takenLocally = false; }

    // Called once per frame from MultiplayerClient::Update() to detect
    // local pickup events. Returns true once on the frame the pickup
    // disappears from the engine pool while we still expected it to
    // be alive.
    bool DetectLocalTake();

private:
    uint16_t  m_id;
    uint16_t  m_model;
    uint8_t   m_type;
    int32_t   m_engineSlot;     // index returned by CPickups::GenerateNewOne, -1 if none
    bool      m_aliveExpected;  // true while we still expect the slot to be alive
    bool      m_takenLocally;
};

} // namespace mp
