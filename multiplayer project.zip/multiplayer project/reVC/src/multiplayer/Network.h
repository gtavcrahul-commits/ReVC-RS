// Network.h - Lightweight TCP socket wrapper for reVC multiplayer.
// POSIX sockets (works on Android NDK and Linux/Termux).
#pragma once

#include <cstdint>
#include <cstddef>
#include <string>

namespace mp {

class TcpClient
{
public:
    TcpClient();
    ~TcpClient();

    // Connect to host:port. Non-blocking after handshake.
    // Returns true on success.
    bool Connect(const std::string& host, uint16_t port);

    void Disconnect();
    bool IsConnected() const { return m_socket >= 0; }

    // Send raw bytes. Returns number of bytes sent (-1 on error).
    int Send(const void* data, size_t len);

    // Non-blocking receive. Returns bytes read, 0 if nothing available,
    // -1 on disconnect/error.
    int Recv(void* buffer, size_t maxLen);

private:
    int m_socket;
};

} // namespace mp
