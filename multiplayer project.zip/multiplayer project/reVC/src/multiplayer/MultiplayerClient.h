// MultiplayerClient.h - Top-level client object: connect, send local state,
// receive snapshots, manage RemotePlayer / RemoteVehicle / RemoteNPC /
// RemotePickup instances, and apply server-authoritative time/weather via
// WorldSync.
#pragma once

#include "Network.h"
#include "Protocol.h"
#include "RemotePlayer.h"
#include "RemoteVehicle.h"
#include "RemoteNPC.h"
#include "RemotePickup.h"
#include "WorldSync.h"

#include <map>
#include <string>
#include <vector>
#include <cstdint>

class CVehicle;

namespace mp {

class MultiplayerClient
{
public:
    struct CfgRef {
        std::string host    = "127.0.0.1";
        uint16_t    port    = 7777;
        std::string name    = "Player";
        bool        enabled = false;
    };

    static MultiplayerClient& Get();

    bool Connect(const std::string& host, uint16_t port, const std::string& name);
    void Disconnect();
    bool IsConnected() const { return m_net.IsConnected(); }

    void Update();

    struct RadarBlip { uint16_t id; float x, y, z; };
    std::vector<RadarBlip> GetRadarBlips() const;

    uint16_t GetLocalPlayerId() const { return m_localId; }

    // True once we have any connection AND have received at least one
    // world tick. Other engine modules (Game.cpp) can use this to gate
    // their local population/traffic generators OFF, since the server
    // is now the authoritative spawner.
    static bool ShouldDisableLocalPopulation();

private:
    MultiplayerClient();
    MultiplayerClient(const MultiplayerClient&) = delete;

    void   ProcessIncoming();
    void   HandleMessage(uint8_t type, const uint8_t* payload, uint16_t len);
    void   HandleSnapshot(const uint8_t* payload, uint16_t len);
    void   HandleVehSnapshot(const uint8_t* payload, uint16_t len);
    void   HandleNpcSnapshot(const uint8_t* payload, uint16_t len);
    void   HandleNpcRemove(const uint8_t* payload, uint16_t len);
    void   HandlePickupSpawn(const uint8_t* payload, uint16_t len);
    void   HandlePickupRemove(const uint8_t* payload, uint16_t len);

    // v3 (v2.2) - spawn oracle: server asks us to use ThePaths to validate
    // a spawn position or pick a wandering waypoint, since the server
    // doesn't have access to game data files.
    void   HandleSpawnQuery(const uint8_t* payload, uint16_t len);
    void   HandleNodeQuery (const uint8_t* payload, uint16_t len);

    void   SendLocalState();
    void   DetectLocalVehicleChange();
    void   DetectLocalPickupTakes();
    void   SendVehEnter(uint16_t model, float x, float y, float z);
    void   SendVehLeave(uint16_t vehNetId);
    void   SendPickupTake(uint16_t pickupId);
    void   DrawHud();
    uint8_t DetectLocalAnimState() const;
    bool   GetLocalPlayerPose(float& x, float& y, float& z, float& heading) const;

    TcpClient                            m_net;
    std::string                          m_name;
    uint16_t                             m_localId;

    std::map<uint16_t, RemotePlayer*>    m_remotes;
    std::map<uint16_t, RemoteVehicle*>   m_vehicles;     // netId -> ghost
    std::map<uint16_t, RemoteNPC*>       m_npcs;         // npcId -> server NPC
    std::map<uint16_t, RemotePickup*>    m_pickups;      // pickupId -> pickup

    // Local vehicle tracking (for entry/exit detection).
    CVehicle*                            m_localVehPtr;     // last seen
    uint16_t                             m_localVehNetId;   // server-assigned, 0 = none
    uint16_t                             m_localVehPendingModel; // awaiting ASSIGN
    uint32_t                             m_localVehEnterSentMs;  // throttle re-send

    std::vector<uint8_t>                 m_recvBuf;

    uint32_t                             m_lastSendMs;
    bool                                 m_autoTried;
    uint32_t                             m_lastReconnectMs;
    CfgRef                               m_cfg;
    static constexpr uint32_t kSendIntervalMs = 66; // ~15 Hz
};

} // namespace mp
