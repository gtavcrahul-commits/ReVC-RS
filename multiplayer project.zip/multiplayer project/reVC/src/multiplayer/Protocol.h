// Protocol.h - Wire format shared by client and server.
//
// Frame format (little-endian):
//   uint16  payloadLen   (does NOT include this 2-byte length prefix)
//   uint8   msgType
//   uint8[] payload
//
// =====================================================================
// v3 (v2.2 release): SERVER-AUTHORITATIVE WORLD with CLIENT SPAWN ORACLE
// ---------------------------------------------------------------------
// Server owns the simulation state (entity ids, positions, lifecycle)
// but doesn't have road/path data - so for any spawn or wander
// waypoint, server asks a connected client to use the engine's
// CPathFind (ThePaths) API and reply with a real, road-valid coord.
// All clients then receive the same authoritative entity snapshot.
//
// Reserved sentinel ids:
//   uint16 ownerPid == 0xFFFF  -> server-owned (NPC traffic)
//   uint16 vehNetId == 0       -> "no vehicle"
//   uint16 playerId == 0xFFFF  -> invalid
// =====================================================================
//
// Player messages
// ---------------
// MSG_HELLO        (client -> server)
//   uint8 nameLen; char name[nameLen]
//
// MSG_WELCOME      (server -> client)
//   uint16 yourId
//
// MSG_STATE        (client -> server, ~15 Hz)
//   float x, y, z          (if vehNetId != 0, this is the VEHICLE pos)
//   float heading          (radians; vehicle heading when in vehicle)
//   uint8 animState        (0=idle, 1=walk, 2=run, 3=sprint, 4=jump)
//   uint16 vehNetId        (0 = on foot; otherwise networked vehicle id)
//
// MSG_SNAPSHOT     (server -> client, ~15 Hz)
//   uint16 count
//   repeated count times: { uint16 pid; float x,y,z; float heading;
//                           uint8 animState; uint16 vehNetId; }
//
// MSG_PLAYER_LEFT  (server -> client)
//   uint16 playerId
//
// Vehicle messages (client-driven cars)
// -------------------------------------
// MSG_VEH_ENTER, MSG_VEH_ASSIGN, MSG_VEH_LEAVE, MSG_VEH_SNAPSHOT
//   (unchanged from v1/v2 - see structs below)
//
// World messages (server-authoritative)
// -------------------------------------
// MSG_WORLD_TICK         (server -> client, ~1 Hz) - time + weather
// MSG_NPC_SNAPSHOT       (server -> client, ~15 Hz) - peds in AOI
// MSG_NPC_REMOVE         (server -> client) - peds that left AOI
// MSG_PICKUP_SPAWN/REMOVE/TAKE (pickup sync, optional in v2.2)
//
// Spawn-oracle messages (NEW in v3 / v2.2)
// ----------------------------------------
// MSG_SPAWN_QUERY        (server -> ONE client, "spawn host")
//   uint16 queryId
//   uint8  type           (0 = PATH_CAR, 1 = PATH_PED)
//   float  hintX, hintY, hintZ   (server's desired centre point)
//   float  minDist, maxDist      (search radius from hint, metres)
//   "Please run ThePaths.GeneratePedCreationCoors / GenerateCarCreationCoors
//    around (hintX, hintY) within [minDist, maxDist] and reply with a
//    valid road/sidewalk coord."
//
// MSG_SPAWN_REPLY        (client -> server)
//   uint16 queryId
//   uint8  ok            (1 = valid coords follow, 0 = no valid spawn)
//   float  x, y, z       (engine-validated position)
//   float  heading       (radians)
//
// MSG_NODE_QUERY         (server -> ONE client)
//   uint16 queryId
//   uint8  type           (0 = PATH_CAR, 1 = PATH_PED)
//   float  curX, curY, curZ      (entity's current position)
//   "Please find the nearest path node and pick a random adjacent
//    node, reply with that node's coords + heading toward it."
//
// MSG_NODE_REPLY         (client -> server)
//   uint16 queryId
//   uint8  ok            (1 = valid waypoint, 0 = no neighbours found)
//   float  x, y, z       (next node's world coords)
//   float  heading       (radians: direction from curr -> next)
//
#pragma once

#include <cstdint>

namespace mp {

enum MsgType : uint8_t {
    MSG_HELLO         = 1,
    MSG_WELCOME       = 2,
    MSG_STATE         = 3,
    MSG_SNAPSHOT      = 4,
    MSG_PLAYER_LEFT   = 5,
    MSG_VEH_ENTER     = 6,
    MSG_VEH_ASSIGN    = 7,
    MSG_VEH_LEAVE     = 8,
    MSG_VEH_SNAPSHOT  = 9,
    // v2 server-authoritative additions
    MSG_WORLD_TICK    = 10,
    MSG_NPC_SNAPSHOT  = 11,
    MSG_NPC_REMOVE    = 12,
    MSG_PICKUP_SPAWN  = 13,
    MSG_PICKUP_REMOVE = 14,
    MSG_PICKUP_TAKE   = 15,
    // v3 (v2.2) spawn-oracle messages
    MSG_SPAWN_QUERY   = 16,
    MSG_SPAWN_REPLY   = 17,
    MSG_NODE_QUERY    = 18,
    MSG_NODE_REPLY    = 19,
};

// Path types - match reVC src/control/PathFind.h enum.
enum PathType : uint8_t {
    PATH_CAR = 0,
    PATH_PED = 1,
};

enum AnimState : uint8_t {
    ANIM_IDLE   = 0,
    ANIM_WALK   = 1,
    ANIM_RUN    = 2,
    ANIM_SPRINT = 3,
    ANIM_JUMP   = 4,
};

#pragma pack(push, 1)

// Player ----------------------------------------------------------------
struct StatePayload {
    float    x, y, z;
    float    heading;
    uint8_t  animState;
    uint16_t vehNetId;       // 0 = on foot
};

struct SnapshotEntry {
    uint16_t playerId;
    float    x, y, z;
    float    heading;
    uint8_t  animState;
    uint16_t vehNetId;       // 0 = on foot
};

// Vehicle ---------------------------------------------------------------
struct VehEnterPayload {
    uint16_t model;
    float    x, y, z;
};

struct VehAssignPayload {
    uint16_t vehNetId;
    uint16_t model;
};

struct VehLeavePayload {
    uint16_t vehNetId;
};

struct VehSnapshotEntry {
    uint16_t vehNetId;
    uint16_t model;
    float    x, y, z;
    float    heading;
    uint16_t ownerPid;       // 0 = unowned, 0xFFFF = server traffic
};

// World tick (time + weather) ------------------------------------------
struct WorldTickPayload {
    uint8_t  hour;
    uint8_t  minute;
    uint8_t  dayOfWeek;
    uint8_t  oldWeather;
    uint8_t  newWeather;
    float    interp;         // 0..1 blend between old and new
};

// NPC ------------------------------------------------------------------
struct NpcSnapshotEntry {
    uint16_t npcId;
    uint16_t model;
    float    x, y, z;
    float    heading;
    uint8_t  animState;
    uint8_t  health;         // 0..200, 0 = dead
};

// Pickup ---------------------------------------------------------------
struct PickupSpawnEntry {
    uint16_t pickupId;
    uint16_t model;
    uint8_t  type;           // engine PICKUP_* enum
    float    x, y, z;
};

struct PickupTakePayload {
    uint16_t pickupId;
};

// Spawn-oracle queries (v3) -------------------------------------------
struct SpawnQueryPayload {
    uint16_t queryId;
    uint8_t  type;           // PATH_CAR | PATH_PED
    float    hintX, hintY, hintZ;
    float    minDist, maxDist;
};

struct SpawnReplyPayload {
    uint16_t queryId;
    uint8_t  ok;
    float    x, y, z;
    float    heading;
};

struct NodeQueryPayload {
    uint16_t queryId;
    uint8_t  type;           // PATH_CAR | PATH_PED
    float    curX, curY, curZ;
};

struct NodeReplyPayload {
    uint16_t queryId;
    uint8_t  ok;
    float    x, y, z;
    float    heading;
};

#pragma pack(pop)

constexpr uint16_t kInvalidPlayerId  = 0xFFFF;
constexpr uint16_t kInvalidVehNetId  = 0;
constexpr uint16_t kServerOwnedPid   = 0xFFFF;

// Protocol version - bump when wire format changes incompatibly.
constexpr uint16_t kProtocolVersion  = 3;

} // namespace mp
