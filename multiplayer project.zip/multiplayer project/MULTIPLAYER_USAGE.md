# reVC Multiplayer — কীভাবে চালাবে (How to play)

## কীভাবে কাজ করে

1. **গেম যেভাবে normally open হয় সেভাবেই open হবে** — আলাদা launcher নেই।
2. গেম শুরু হলেই multiplayer client একটা config file পড়ে এবং **automatically connect** করে।
3. উপরে-বাম কোণে সবুজ লেখায় status দেখাবে (এটাই proof multiplayer চলছে):
   - `MP: connecting 192.168.1.10:7777 ...` → connecting
   - `MP: ONLINE  id=1  peers=2`              → connected, ২ জন peer আছে
   - কিছুই না দেখালে → config file নেই, multiplayer disabled

## Step-by-step setup (২ জন player)

### Step 1 — Server চালাও (একজন player বা একটা PC)

PC বা Termux-এ:
```bash
cd server
python3 server.py
```
এটা port `7777`-এ listen করবে। Server-এর IP লাগবে (e.g. `192.168.1.10`).
দুজনই same WiFi-তে থাকতে হবে, অথবা server-এর IP public/port-forwarded থাকতে হবে।

### Step 2 — Player A: গেম একবার open করো

প্রথম বার open করলে multiplayer কিছু করবে না, কিন্তু এটা auto-create করবে:
```
/sdcard/Android/data/com.revc.game/files/multiplayer.cfg
```
যেটা দেখতে এরকম:
```
# reVC multiplayer config -- edit and restart the game
server_ip=127.0.0.1
server_port=7777
player_name=Player
```

গেম থেকে বের হও।

### Step 3 — File Manager খুলে config edit করো

ওই `multiplayer.cfg` file edit করো:
```
server_ip=192.168.1.10      ← server-এর actual IP
server_port=7777
player_name=Rahul           ← তোমার নাম
```

### Step 4 — Player B: একই কাজ করো ওর phone-এ

ওর phone-এ same APK install, একবার গেম open, তারপর `multiplayer.cfg` edit:
```
server_ip=192.168.1.10      ← একই server IP
server_port=7777
player_name=Karim           ← আলাদা নাম
```

### Step 5 — দুজনই গেম restart করো

দুজনের screen-এর উপরে-বামে দেখবে:
```
MP: ONLINE  id=1  peers=1
```

`peers=1` মানে ১ জন other player connected। তখন map-এ ঘুরলেই অন্য player-কে CPed হিসেবে দেখতে পাবে — সে যেখানে যায় তোমার screen-এ সেটা দেখাবে (15 Hz update rate, smooth interpolation)।

## Multiplayer চলছে কিনা কীভাবে বুঝবে

| Indicator | মানে |
|---|---|
| 🟢 উপরে-বাম-এ `MP: ONLINE` | Connected, working |
| 🟡 `MP: connecting ...` | Server-এ পৌঁছাতে পারছে না (IP/port/firewall check করো) |
| ⚪ কিছুই দেখাচ্ছে না | Config file নেই বা multiplayer disabled |
| 👥 অন্য player-এর CPed map-এ দেখা | সব ঠিকঠাক চলছে |

## Server logs দেখা

Server terminal-এ দেখবে:
```
[server] listening on 0.0.0.0:7777
[server] Rahul (id=1) joined from 192.168.1.5
[server] Karim (id=2) joined from 192.168.1.6
[server] tick: 2 players online
```

## Client logs দেখা (debug)

PC-তে USB দিয়ে phone connect করে:
```bash
adb logcat | grep reVC_MP
```

আউটপুট:
```
reVC_MP: config loaded: host=192.168.1.10 port=7777 name=Rahul
reVC_MP: connecting to 192.168.1.10:7777 as 'Rahul' ...
reVC_MP: TCP connected, sending HELLO
reVC_MP: WELCOME: localId=1
reVC_MP: spawned remote player id=2
```

## সমস্যা হলে

- **`MP: connecting...` থেকে আগায় না:** server-এর IP ভুল, server চলছে না, বা firewall block করছে। দুজনই same WiFi/network-এ আছে কিনা check করো।
- **Server console-এ "joined" দেখায় কিন্তু client-এ peer 0:** snapshot reach করছে না — তোমার server tick rate check করো (default 15 Hz), client-side TCP receive log দেখো `adb logcat`-এ।
- **Other player-এর CPed দেখা যায় না কিন্তু `peers=1` দেখায়:** spawn fail হয়েছে — সাধারণত position invalid (water-এর তলায় বা মানচিত্রের বাইরে)। অন্য জনকে valid জায়গায় যেতে বলো।

## Caveat (আগেও বলেছিলাম)

APK চলবে শুধু যদি GTA: Vice City original game assets থাকে এই path-এ:
```
/sdcard/Android/data/com.revc.game/files/
├── models/
├── audio/
├── data/
└── ...
```
এসব assets reVC repo-তে নেই (copyright)। তোমার নিজের কপি লাগবে।
