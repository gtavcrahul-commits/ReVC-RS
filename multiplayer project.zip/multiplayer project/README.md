# reVC-RS Server-Authoritative Multiplayer (v2.2)

A server-authoritative multiplayer layer for the reVC (Vice City
reverse-engineered) **Android build**. Adds a thin networking layer on
top of the engine without modifying the core. The Python server owns
the entire shared world simulation:

- Time of day + weather (every client sees the same sky)
- Pedestrian NPCs (server spawns + walks them; same NPC visible to all
  players inside its Area-Of-Interest)
- Traffic vehicles (server-spawned, broadcast inside AOI)
- Player-driven vehicles (jacking + ownership transfer)
- Pickups (server tracks taken / respawn timer)

Clients are **render + input devices**. Local population, traffic
generators and pickup spawners are gated off whenever the multiplayer
client is connected, so there are no duplicate / desynced entities.

### v2.2: spawn-oracle architecture (the working version)

The server doesn't have access to the engine's road / sidewalk path
data, so v2.1 had to ship with NPC and traffic spawning **disabled**
(spawning at random positions dropped cars into buildings and the
ocean, crashing the engine). v2.2 fixes this by introducing a
**spawn-oracle protocol**:

- When the server wants to spawn or move an NPC / traffic car, it
  sends `MSG_SPAWN_QUERY` or `MSG_NODE_QUERY` to ONE connected client
  (the "oracle" - usually the player nearest to the entity).
- The oracle's client runs `ThePaths.GeneratePedCreationCoors`,
  `GenerateCarCreationCoors`, or `FindNextNodeWandering` (the engine's
  own path-network helpers) and replies with engine-validated coords.
- The server then broadcasts the resulting entity to **all** players
  in AOI via the normal `MSG_NPC_SNAPSHOT` / `MSG_VEH_SNAPSHOT` -
  every player sees the same pedestrian on the same sidewalk and the
  same car on the same road.

Net effect: NPCs and traffic are **on by default** in v2.2, run on
real roads/sidewalks, and stay synchronised across all clients.

---

## Layout

```
multiplayer project/
├── reVC/                           # full reVC engine source tree
│   └── src/multiplayer/            # Drop-in / already-in-place package
│       ├── Network.h / .cpp        # POSIX TCP socket wrapper
│       ├── Protocol.h              # Wire format (15 message types)
│       ├── RemotePlayer.h / .cpp   # Other connected players
│       ├── RemoteVehicle.h / .cpp  # Player-owned + server-traffic ghosts
│       ├── RemoteNPC.h / .cpp      # NEW: server-driven pedestrians
│       ├── RemotePickup.h / .cpp   # NEW: server-driven pickups
│       ├── WorldSync.h / .cpp      # NEW: applies time + weather
│       └── MultiplayerClient.h/.cpp# Singleton client, called once per frame
├── server/
│   └── server.py                   # Server-authoritative world simulator
├── patches/
│   └── Game.cpp.patch              # Disable local population/traffic
│                                   #   when MP client is connected
├── PHASES.md                       # Phase-by-phase implementation log
├── MULTIPLAYER_USAGE.md            # End-user guide (Bangla)
└── README.md
```

---

## Android client integration

### 1. Drop the multiplayer folder into your engine tree

Copy `reVC/src/multiplayer/` (this entire folder) over the same path in
your `gtavcrahul-commits/ReVC-RS` checkout. The build glob in both
premake and cmake covers `src/**/*.cpp`, so no build-system edits are
needed beyond the file copy.

### 2. Add the per-frame hook in `CGame::Process`

Edit `reVC/src/core/Game.cpp`:

```cpp
#include "multiplayer/MultiplayerClient.h"
```

Inside `void CGame::Process(void)`, right after:

```cpp
PUSH_MEMID(MEMID_WORLD);
CWorld::Process();
POP_MEMID();
```

add:

```cpp
mp::MultiplayerClient::Get().Update();
```

### 3. Apply the population/traffic disable patch

Apply the patch from the project root of `ReVC-RS`:

```bash
git apply patches/Game.cpp.patch
```

What it does: when the multiplayer client is connected, the engine
skips `CPopulation::Update`, `CTheCarGenerators::Process` and
`CCarCtrl::GenerateRandomCars`. Those local spawners would fight the
server's authoritative entities and create duplicates. When MP is
disconnected, the engine behaves exactly like single-player.

### 4. Build the APK

For Android, the existing NDK toolchain compiles the new sources as
plain C++17 — no extra system libraries required, only POSIX sockets,
which the NDK provides out of the box.

```bash
# from your ReVC-RS root
./gradlew assembleRelease         # or whatever Android build target
                                  # the rest of the repo uses
```

(Replit can't build the Android NDK toolchain or run an APK — do this
on your local Android Studio / NDK install.)

### 5. Configure server connection

On first launch the client writes a default config to:
```
/sdcard/Android/data/com.revc.game/files/multiplayer.cfg
```

Edit it to point at your server (Termux IP or LAN IP). See
`MULTIPLAYER_USAGE.md` for the step-by-step Bangla guide.

---

## Server (Termux / Linux)

```bash
pkg install python                  # Termux
python3 server/server.py            # 0.0.0.0:7777
python3 server/server.py 9000       # custom port
```

Tunables (top of `server.py`):

| Setting                    | Default | Meaning                                   |
|----------------------------|---------|-------------------------------------------|
| `TICK_HZ`                  | 15      | Player + entity snapshot rate             |
| `WORLD_TICK_HZ`            | 1       | Time/weather push rate                    |
| `AOI_RADIUS`               | 150 m   | Per-player Area-Of-Interest radius        |
| `NPC_TARGET_PER_PLAYER`    | 6       | Target NPC density near each player       |
| `NPC_POOL_LIMIT`           | 60      | Hard cap                                  |
| `TRAFFIC_TARGET_PER_PLAYER`| 4       | Target traffic vehicles per player        |
| `TRAFFIC_POOL_LIMIT`       | 40      | Hard cap                                  |
| `WEATHER_PHASE_SEC`        | 300 s   | Real-seconds per weather phase            |
| `TIME_MIN_PER_SEC`         | 1.0     | In-game minutes per real second           |
| `PICKUP_RESPAWN_SEC`       | 60 s    | How long after pickup take it respawns    |
| `QUERY_TIMEOUT_SEC`        | 2.0 s   | Drop oracle queries that don't reply      |

---

## Wire protocol

Frame: `uint16 payloadLen` (LE) + `uint8 type` + `payload`.

| #  | Type              | Direction | Purpose |
|----|-------------------|-----------|---------|
| 1  | HELLO             | C→S | Login (name) |
| 2  | WELCOME           | S→C | Assigned player id |
| 3  | STATE             | C→S | Local pose + anim + vehNetId |
| 4  | SNAPSHOT          | S→C | Other players in AOI |
| 5  | PLAYER_LEFT       | S→C | A player disconnected |
| 6  | VEH_ENTER         | C→S | "I just got into a car" |
| 7  | VEH_ASSIGN        | S→C | "Here's its netId" |
| 8  | VEH_LEAVE         | C→S | "I exited the car" |
| 9  | VEH_SNAPSHOT      | S→C | All vehicles in AOI (player + traffic) |
| 10 | WORLD_TICK        | S→C | Time + weather (1 Hz) |
| 11 | NPC_SNAPSHOT      | S→C | Pedestrian NPCs in AOI |
| 12 | NPC_REMOVE        | S→C | Drop these NPCs |
| 13 | PICKUP_SPAWN      | S→C | New pickups in AOI |
| 14 | PICKUP_REMOVE     | S→C | Drop these pickups |
| 15 | PICKUP_TAKE       | C→S | "I just collected this pickup" |
| 16 | SPAWN_QUERY       | S→C | "Validate a spawn coord around (x,y) using ThePaths" |
| 17 | SPAWN_REPLY       | C→S | Engine-validated spawn coord |
| 18 | NODE_QUERY        | S→C | "Pick the next wandering waypoint near (x,y)" |
| 19 | NODE_REPLY        | C→S | Next path-node coord + heading |

Animation states: 0 idle / 1 walk / 2 run / 3 sprint / 4 jump.

Reserved sentinels: `vehNetId == 0` ("on foot"),
`ownerPid == 0xFFFF` ("server-owned traffic"),
`playerId == 0xFFFF` ("invalid").

Full per-message struct layout: see `reVC/src/multiplayer/Protocol.h`.

---

## Design notes

- **Server is the single source of truth.** Clients never spawn
  entities themselves. The Game.cpp patch turns off local
  population/traffic generators while connected; with that gate,
  every client sees the same NPCs and the same traffic.
- **AOI streaming.** Each player only receives the entities (NPCs,
  vehicles, pickups, other players) within `AOI_RADIUS`. NPC removals
  are computed per-player by diffing against what the server
  previously sent that client.
- **Continuous push.** Server pushes 15 Hz entity snapshots and 1 Hz
  world ticks. Clients send only their own STATE plus event messages
  (VEH_ENTER/LEAVE, PICKUP_TAKE) — no request model.
- **No engine changes beyond two hooks.** All multiplayer logic is in
  `src/multiplayer/`. The two engine-side touches are the
  `MultiplayerClient::Get().Update()` call and the population/traffic
  guards. Easy to rebase against upstream reVC.
- **Remote players are real CCivilianPeds**, kept in `CWorld`,
  rendered/collided/animated by the engine. AI is parked
  (`bRespondsToThreats=false`) and pose is driven by the network with
  smoothed interpolation between the previous and target snapshot.
- **TCP first.** Latency is fine on LAN/Wi-Fi for v1/v2. Swap
  `Network.*` for an ENet/UDP backend later without touching the
  rest of the protocol.
- **Pool ceilings respected.** Server caps NPC count at 140 and
  traffic at 110 (matching engine pool sizes), and despawns
  aggressively outside AOI.

---

## Phase summary

| Phase | Status | Notes |
|-------|--------|-------|
| 1. Time + Weather sync   | ✅ | `MSG_WORLD_TICK` + `WorldSync` (only re-applied on actual change so engine interpolation isn't fought every tick) |
| 2. Pickup sync           | ⚠️ | Wire format + `RemotePickup` ready; `PICKUP_SPAWN_POINTS` empty by default until verified pickup coords are added |
| 3. Vehicle sync fix      | ✅ | Player-owned + server traffic share `MSG_VEH_SNAPSHOT` |
| 4. NPC sync              | ✅ | v2.2: server spawns + wanders peds via spawn-oracle (`SPAWN_QUERY` / `NODE_QUERY` to closest client; `ThePaths.GeneratePedCreationCoors` + `FindNextNodeWandering` validate every coord) |
| 5. Traffic sync          | ✅ | v2.2: same spawn-oracle for cars (`PATH_CAR`); `GenerateCarCreationCoors` keeps cars on real roads |
| 6. Optimization          | ⏳ | UDP/ENet, delta compression, int16 pose quantisation, prediction (future) |

`MultiplayerClient::ShouldDisableLocalPopulation()` returns `true` once
the client is connected AND has received its first WORLD_TICK. That
gate (via `patches/Game.cpp.patch`) silences the engine's vanilla ped
and traffic generators, so there's no duplication with the server's
authoritative entities.

See `PHASES.md` for implementation details per phase.

---

## What I could not do from here

This Replit environment can't build the Android NDK toolchain or run
an APK. So you should:

1. Copy the files from `multiplayer project/reVC/src/multiplayer/`
   into your `ReVC-RS` repo's `reVC/src/multiplayer/`.
2. Apply `patches/Game.cpp.patch` and add the
   `mp::MultiplayerClient::Get().Update()` line in `CGame::Process`.
3. Build the APK with your normal Android NDK setup.
4. Run `python3 server/server.py` in Termux on one device.
5. On 2+ devices/emulators, launch the APK; once `multiplayer.cfg`
   points at the server you'll see the HUD switch from
   `MP: connecting ...` to `MP: ONLINE ... WORLD` and pedestrians /
   traffic / pickups will populate around all players.
